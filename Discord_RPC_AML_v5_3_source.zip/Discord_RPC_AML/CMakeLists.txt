cmake_minimum_required(VERSION 3.22)
project(hexed_discord_rpc LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)
set(CMAKE_VISIBILITY_INLINES_HIDDEN ON)
# size optimization, applied to every ABI (armeabi-v7a 32-bit and arm64-v8a 64-bit) and to both libs we build
# (libDiscord_RPC.so, libhxrpc_core.so). Strip keeps the dynamic exports AML / JNI need (they have default visibility).
add_compile_options(-Os -flto -ffunction-sections -fdata-sections)
add_link_options(-flto -Wl,--gc-sections -Wl,--icf=all -Wl,--exclude-libs,ALL -Wl,--strip-all)

# Discord application id used when the INI has no appid (v5.1: the GTA San Andreas id supplied by the user). Override: -DHX_APP_ID=...
set(HX_APP_ID "363447565905166336" CACHE STRING "Discord application id")

set(SDK_DIR ${CMAKE_SOURCE_DIR}/third_party/lib/${ANDROID_ABI})

# ---- core: Discord Social SDK + presence. Loaded by HxBridge (Java), NOT by AML ------------------
add_library(hxrpc_core SHARED src/core.cpp)
set_target_properties(hxrpc_core PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/payload)
target_include_directories(hxrpc_core PRIVATE third_party/include src)
target_link_directories(hxrpc_core PRIVATE ${SDK_DIR})
target_link_libraries(hxrpc_core PRIVATE discord_partner_sdk log)   # NEEDED = libdiscord_partner_sdk.so (its SONAME)
target_link_options(hxrpc_core PRIVATE -Wl,--gc-sections)

# ---- the AML mod (libDiscord_RPC.so): small stub, no link dependency on the SDK ------------------
add_library(Discord_RPC SHARED src/stub.cpp)
add_dependencies(Discord_RPC hxrpc_core)
target_include_directories(Discord_RPC PRIVATE third_party/aml src)
target_compile_definitions(Discord_RPC PRIVATE HX_DEFAULT_APP_ID=${HX_APP_ID}ULL)
if(ANDROID_ABI STREQUAL "armeabi-v7a")
    target_compile_definitions(Discord_RPC PRIVATE AML32)
endif()
target_link_libraries(Discord_RPC PRIVATE log dl)
target_link_options(Discord_RPC PRIVATE -Wl,--gc-sections)
