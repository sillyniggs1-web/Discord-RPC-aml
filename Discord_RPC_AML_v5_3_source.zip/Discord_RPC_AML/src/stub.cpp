// Hexed Discord RPC - AML mod (libDiscord_RPC.so)  [v5: pure game activity, starts by itself, no Lua needed]
// This is the file AML loads. It stays small and has no link dependency on the Discord SDK:
//   1. finds the support folder Discord_RPC/ (libhxrpc_core_v4.so, libdiscord_partner_sdk.so, hx_dex_v3.jar) - next to
//      this .so, or in any AML folder - and copies the files into the app's private dir <filesDir>/hxrpc
//   2. builds a DexClassLoader with the SDK's Java classes + HxBridge
//   3. HxBridge gives the SDK the game's Activity and System.load()s the SDK and the core through that loader
//   4. fetches the core's function table and starts the activity (a background thread does this ~10 s after the mod loaded)

#include "mod/amlmod.h"
#include <jni.h>
#include <android/log.h>
#include <dirent.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>
#include <atomic>
#include <vector>
#include "api.h"

#ifndef HX_DEFAULT_APP_ID
#define HX_DEFAULT_APP_ID 0ULL
#endif

#define TAG "HexedRPC"

MYMOD(net.hexedstudio.discordrpc, Hexed Discord RPC, 5.3.0, HEXED Studio)

namespace {

std::mutex g_mu;
bool g_javaFailed = false;   // Java stage failed: a second try in the same process cannot work, needs a game restart
HxApi* g_api = nullptr;
char g_err[512] = "not started";
std::string g_work;          // <filesDir>/hxrpc, also where the log lives
std::string g_logPath;

std::string g_srcDir;        // folder the support files were found in (the INI lives there too)
std::string g_probe;         // what HxBridge.probe() saw: Android level, is the Discord app visible, is its RPC service there

void logLine(const std::string& s) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", s.c_str());
    if (g_logPath.empty()) return;
    if (FILE* f = std::fopen(g_logPath.c_str(), "a")) {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);
        char ts[16];
        std::strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        std::fprintf(f, "%s stub  %s\n", ts, s.c_str());
        std::fclose(f);
    }
}

void setErr(const std::string& s) {
    std::snprintf(g_err, sizeof(g_err), "%s", s.c_str());
    logLine("ERROR: " + s);
}

// Java-stage failure: remember it, a retry would only hit "Could not initialize class"
bool failJava(const std::string& s) {
    g_javaFailed = true;
    setErr(s + " (restart the game after fixing this)");
    return false;
}

// ---------------------------------------------------------------- support files (Discord_RPC/ folder)

std::string modDir() {
    Dl_info info{};
    if (!dladdr(reinterpret_cast<void*>(&modDir), &info) || !info.dli_fname) return ".";
    std::string p = info.dli_fname;
    auto slash = p.find_last_of('/');
    return slash == std::string::npos ? "." : p.substr(0, slash);
}

const char* const kSdk  = "libdiscord_partner_sdk.so";
const char* const kCore = "libhxrpc_core_v5.so";   // _v<HX_API_VERSION>: stale cores from older builds are ignored
const char* const kDex  = "hx_dex_v3.jar";

bool fileOk(const std::string& p) {
    struct stat st{};
    return stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0 && access(p.c_str(), R_OK) == 0;
}

bool dirHasSupport(const std::string& d) {
    return fileOk(d + "/" + kSdk) && fileOk(d + "/" + kCore) && fileOk(d + "/" + kDex);
}

std::string missingIn(const std::string& d) {
    std::string m;
    for (const char* f : { kSdk, kCore, kDex })
        if (!fileOk(d + "/" + f)) m += std::string(m.empty() ? "" : ", ") + f;
    return m;
}

// "" = ok, otherwise what went wrong (with errno)
std::string copyFile(const std::string& from, const std::string& to, mode_t mode) {
    FILE* in = std::fopen(from.c_str(), "rb");
    if (!in) return "cannot read " + from + " (" + std::strerror(errno) + ")";
    std::fseek(in, 0, SEEK_END);
    long size = std::ftell(in);
    std::fseek(in, 0, SEEK_SET);
    struct stat a{}, b{};
    if (stat(to.c_str(), &b) == 0 && b.st_size == size && stat(from.c_str(), &a) == 0 && b.st_mtime >= a.st_mtime) {
        std::fclose(in);
        return "";   // already current
    }
    unlink(to.c_str());   // may be read-only
    FILE* out = std::fopen(to.c_str(), "wb");
    if (!out) { std::string e = std::strerror(errno); std::fclose(in); return "cannot write " + to + " (" + e + ")"; }
    char buf[1 << 15];
    size_t n;
    bool ok = true;
    while ((n = std::fread(buf, 1, sizeof(buf), in)) > 0)
        if (std::fwrite(buf, 1, n, out) != n) { ok = false; break; }
    std::fclose(in);
    if (std::fclose(out) != 0) ok = false;
    if (!ok) return "write failed for " + to + " (" + std::strerror(errno) + ")";
    chmod(to.c_str(), mode);
    return "";
}

// ---- where are the support files? -------------------------------------------------------------
// AML may load this .so from a different place than the folder the user copied it to (some AML
// versions copy mods into private storage first), so "next to the .so" is only the first guess.

std::vector<std::string> baseDirs() {
    std::vector<std::string> b;
    auto add = [&](const std::string& raw) {
        std::string s = raw;
        while (s.size() > 1 && s.back() == '/') s.pop_back();
        if (s.empty()) return;
        for (const auto& x : b) if (x == s) return;
        b.push_back(s);
    };
    auto addc = [&](const char* p) { if (p && *p) add(p); };
    add(modDir());
    addc(aml->GetInternalModsPath());
    addc(aml->GetAndroidDataPath());
    addc(aml->GetAndroidDataRootPath());
    addc(aml->GetConfigPath());
    addc(aml->GetDataPath());
    return b;
}

void scanDirs(const std::string& root, int depth, int& budget, std::vector<std::string>& found) {
    if (depth < 0 || budget <= 0 || found.size() >= 4) return;
    --budget;
    if (dirHasSupport(root + "/Discord_RPC")) found.push_back(root + "/Discord_RPC");
    DIR* d = opendir(root.c_str());
    if (!d) return;
    while (dirent* e = readdir(d)) {
        if (e->d_name[0] == '.') continue;
        if (e->d_type == DT_DIR || e->d_type == DT_UNKNOWN) scanDirs(root + "/" + e->d_name, depth - 1, budget, found);
        if (found.size() >= 4 || budget <= 0) break;
    }
    closedir(d);
}

// returns the folder holding all three files, "" if none; `tried` lists what was checked
std::string findSupportDir(std::string& tried) {
    const auto bases = baseDirs();
    auto check = [&](const std::string& dir) {
        if (dirHasSupport(dir)) return true;
        if (tried.size() < 300) tried += (tried.empty() ? "" : " | ") + dir;
        return false;
    };
    for (const auto& b : bases) {
        if (check(b + "/Discord_RPC")) return b + "/Discord_RPC";
        if (check(b)) return b;
    }
    int budget = 1500;
    std::vector<std::string> found;
    for (const auto& b : bases) {
        scanDirs(b, 3, budget, found);
        if (!found.empty()) break;
    }
    return found.empty() ? std::string() : found.front();
}


// copies the three support files from `src` into `work`; "" = ok, otherwise what went wrong
std::string copySupport(const std::string& src, const std::string& work) {
    bool dexChanged = false;
    for (const char* f : { kSdk, kCore, kDex }) {
        struct stat before{};
        const bool had = stat((work + "/" + f).c_str(), &before) == 0;
        const std::string e = copyFile(src + "/" + f, work + "/" + f, std::strcmp(f, kDex) == 0 ? 0444 : 0755);
        if (!e.empty()) return e;
        struct stat after{};
        if (std::strcmp(f, kDex) == 0 && (!had || (stat((work + "/" + f).c_str(), &after) == 0 && (after.st_mtime != before.st_mtime || after.st_size != before.st_size))))
            dexChanged = true;
    }
    // the DexClassLoader writes optimized code into odex/: stale output from an older dex must go
    if (dexChanged) unlink((work + "/odex/hx_dex_v3.dex").c_str());
    return "";
}

// ---------------------------------------------------------------- JNI helpers

JNIEnv* jenv() {
    JavaVM* vm = aml->GetJavaVM();
    if (!vm) return nullptr;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) return env;
    if (vm->AttachCurrentThread(&env, nullptr) == JNI_OK) return env;
    return nullptr;
}

// description of a pending Java exception, then clear it
std::string takeException(JNIEnv* env) {
    if (!env->ExceptionCheck()) return "";
    jthrowable t = env->ExceptionOccurred();
    env->ExceptionClear();
    std::string out = "Java exception";
    jclass tc = env->FindClass("java/lang/Throwable");
    jmethodID ts = env->GetMethodID(tc, "toString", "()Ljava/lang/String;");
    if (ts && t) {
        jstring js = (jstring)env->CallObjectMethod(t, ts);
        if (js) {
            const char* c = env->GetStringUTFChars(js, nullptr);
            if (c) { out = c; env->ReleaseStringUTFChars(js, c); }
        }
    }
    env->ExceptionClear();
    return out;
}

std::string javaString(JNIEnv* env, jobject obj, const char* method) {
    jclass c = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(c, method, "()Ljava/lang/String;");
    if (!m) { env->ExceptionClear(); return ""; }
    jstring s = (jstring)env->CallObjectMethod(obj, m);
    if (!s) return "";
    const char* c8 = env->GetStringUTFChars(s, nullptr);
    std::string r = c8 ? c8 : "";
    if (c8) env->ReleaseStringUTFChars(s, c8);
    return r;
}

bool bootstrap() {
    JNIEnv* env = jenv();
    if (!env) { setErr("no JNIEnv (AML gave no JavaVM / attach failed)"); return false; }

    // only the app context is requested from AML (works on every AML version); HxBridge finds the Activity by itself
    jobject ctx = aml->GetCurrentContext();
    if (!ctx) { setErr("no app context from AML"); return false; }

    // --- private working dir: <filesDir>/hxrpc
    jclass ctxCls = env->GetObjectClass(ctx);
    jmethodID getFiles = env->GetMethodID(ctxCls, "getFilesDir", "()Ljava/io/File;");
    jobject filesDir = getFiles ? env->CallObjectMethod(ctx, getFiles) : nullptr;
    if (!filesDir) { setErr("getFilesDir failed: " + takeException(env)); return false; }
    const std::string work = javaString(env, filesDir, "getAbsolutePath") + "/hxrpc";
    mkdir(work.c_str(), 0700);
    mkdir((work + "/odex").c_str(), 0700);
    g_work = work;
    g_logPath = work + "/hxrpc.log";
    {   // keep the log small: start a fresh one when it grew past 256 KB
        struct stat st{};
        if (stat(g_logPath.c_str(), &st) == 0 && st.st_size > 256 * 1024) unlink(g_logPath.c_str());
    }
    logLine("bootstrap, work dir " + work);

    // --- find the support files and copy them out of the mods folder (not a Java failure: can be retried)
    {
        std::string tried;
        const std::string src = findSupportDir(tried);
        if (!src.empty()) {
            logLine("support files found in " + src);
            g_srcDir = src;
            const std::string e = copySupport(src, work);
            if (!e.empty()) { setErr(e); return false; }
        } else if (dirHasSupport(work)) {
            logLine("support folder not found, reusing the files copied earlier in " + work);
        } else {
            const std::string first = modDir() + "/Discord_RPC";
            setErr("Support files not found (" + missingIn(first) + " missing in " + first + "). Mod was loaded from " +
                   modDir() + ". Looked in: " + tried);
            return false;
        }
    }

    // --- DexClassLoader(dexPath, odexDir, libDir, parent = the game's loader)
    jmethodID getLoader = env->GetMethodID(ctxCls, "getClassLoader", "()Ljava/lang/ClassLoader;");
    jobject parent = env->CallObjectMethod(ctx, getLoader);
    jclass dcl = env->FindClass("dalvik/system/DexClassLoader");
    jmethodID dclInit = env->GetMethodID(dcl, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
    jstring jDex = env->NewStringUTF((work + "/" + kDex).c_str());
    jstring jOpt = env->NewStringUTF((work + "/odex").c_str());
    jstring jLib = env->NewStringUTF(work.c_str());
    jobject loader = env->NewObject(dcl, dclInit, jDex, jOpt, jLib, parent);
    if (!loader) return failJava("DexClassLoader: " + takeException(env));

    jmethodID loadClass = env->GetMethodID(dcl, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    jstring jName = env->NewStringUTF("com.hexed.rpc.HxBridge");
    jclass bridge = (jclass)env->CallObjectMethod(loader, loadClass, jName);
    if (!bridge) return failJava("loadClass HxBridge: " + takeException(env));
    bridge = (jclass)env->NewGlobalRef(bridge);

    // --- HxBridge.init(ctx, sdkPath, corePath)
    jmethodID init = env->GetStaticMethodID(bridge, "init",
        "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    if (!init) return failJava("HxBridge.init not found: " + takeException(env));
    jstring jSdk  = env->NewStringUTF((work + "/" + kSdk).c_str());
    jstring jCore = env->NewStringUTF((work + "/" + kCore).c_str());
    jstring res = (jstring)env->CallStaticObjectMethod(bridge, init, ctx, jSdk, jCore);
    if (env->ExceptionCheck()) return failJava("HxBridge.init: " + takeException(env));
    if (res) {
        const char* c = env->GetStringUTFChars(res, nullptr);
        const std::string msg = std::string("HxBridge.init: ") + (c ? c : "?");
        if (c) env->ReleaseStringUTFChars(res, c);
        return failJava(msg);
    }

    // --- HxBridge.apiTable() -> function table inside the core
    jmethodID tbl = env->GetStaticMethodID(bridge, "apiTable", "()J");
    jlong addr = tbl ? env->CallStaticLongMethod(bridge, tbl) : 0;
    if (env->ExceptionCheck()) return failJava("apiTable: " + takeException(env));
    g_api = reinterpret_cast<HxApi*>(static_cast<intptr_t>(addr));
    if (!g_api) return failJava("core returned no API table");
    if (g_api->version != HX_API_VERSION) {
        const int got = g_api->version;
        g_api = nullptr;
        return failJava("core API mismatch (core v" + std::to_string(got) + ", mod expects v" +
                        std::to_string(HX_API_VERSION) + "): an old libhxrpc_core was loaded");
    }

    // --- can this process see the Discord app and its RPC service? (the usual reason for "not reachable")
    {
        jmethodID probe = env->GetStaticMethodID(bridge, "probe", "(Landroid/content/Context;)Ljava/lang/String;");
        if (probe) {
            jstring ps = (jstring)env->CallStaticObjectMethod(bridge, probe, ctx);
            if (!env->ExceptionCheck() && ps) {
                const char* c = env->GetStringUTFChars(ps, nullptr);
                if (c) { g_probe = c; env->ReleaseStringUTFChars(ps, c); }
            }
        }
        env->ExceptionClear();
        logLine("probe: " + (g_probe.empty() ? std::string("(unavailable)") : g_probe));
    }

    std::snprintf(g_err, sizeof(g_err), "ok");
    logLine("bootstrap ok");
    return true;
}



// ---------------------------------------------------------------- tiny INI  (Discord_RPC/Discord_RPC.ini)

struct Cfg {
    bool enabled = true;
    unsigned long long appId = 0;   // 0 = built-in default (HX_APP_ID)
    bool timer = true;
    std::string name = "Grand Theft Auto: San Andreas";   // sent as the activity name (empty in the INI = same default)
};

Cfg loadCfg() {
    Cfg c;
    const std::string path = (g_srcDir.empty() ? g_work : g_srcDir) + "/Discord_RPC.ini";
    FILE* f = std::fopen(path.c_str(), "r");
    if (!f) {
        if (FILE* w = std::fopen(path.c_str(), "w")) {   // best effort: write a default file once
            std::fputs("; Hexed Discord RPC v5 - pure game activity\n"
                       "; enabled: 1 = publish the activity when the game starts\n"
                       "; appid  : Discord application id (empty = built-in 363447565905166336, GTA San Andreas). Its NAME and App Icon are what Discord shows.\n"
                       "; timer  : 1 = \"playing for X minutes\"\n"
                       "; name   : activity name shown by Discord (empty = Grand Theft Auto: San Andreas)\n"
                       "enabled = 1\nappid =\ntimer = 1\nname = Grand Theft Auto: San Andreas\n", w);
            std::fclose(w);
        }
        return c;
    }
    char line[512];
    while (std::fgets(line, sizeof(line), f)) {
        std::string l = line;
        auto trim = [](std::string& x) {
            size_t b = 0, e = x.size();
            while (b < e && (x[b] == ' ' || x[b] == '\t' || x[b] == '\r' || x[b] == '\n')) ++b;
            while (e > b && (x[e - 1] == ' ' || x[e - 1] == '\t' || x[e - 1] == '\r' || x[e - 1] == '\n')) --e;
            x = x.substr(b, e - b);
        };
        trim(l);
        if (l.empty() || l[0] == ';' || l[0] == '#' || l[0] == '[') continue;
        const auto eq = l.find('=');
        if (eq == std::string::npos) continue;
        std::string k = l.substr(0, eq), v = l.substr(eq + 1);
        trim(k); trim(v);
        const bool on = !(v == "0" || v == "false" || v == "off" || v == "no");
        if (k == "enabled") c.enabled = on;
        else if (k == "timer") c.timer = on;
        else if (k == "appid") c.appId = v.empty() ? 0ULL : std::strtoull(v.c_str(), nullptr, 10);
        else if (k == "name") { if (!v.empty()) c.name = v; }   // empty keeps the built-in default
    }
    std::fclose(f);
    return c;
}

// bootstrap (once) + start. 1 = running.
int startOnce() {
    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_api) {
        if (g_javaFailed) return 0;
        if (!bootstrap()) return 0;
    }
    const Cfg c = loadCfg();
    if (!c.enabled) { std::snprintf(g_err, sizeof(g_err), "disabled in Discord_RPC.ini"); logLine("disabled in Discord_RPC.ini"); return 1; }
    const unsigned long long id = c.appId ? c.appId : HX_DEFAULT_APP_ID;
    if (id == 0) { setErr("no Discord application id"); return 0; }
    return g_api->start(id, g_work.c_str(), c.timer ? 1 : 0, c.name.c_str());
}

std::atomic<bool> g_quit{false};
std::thread g_boot;

// Waits for the game's Activity to exist, then starts. File problems are retried; a Java-stage failure is final.
void bootThread() {
    for (int i = 0; i < 100 && !g_quit; ++i) std::this_thread::sleep_for(std::chrono::milliseconds(100));   // ~10 s
    for (int attempt = 1; attempt <= 12 && !g_quit; ++attempt) {
        if (startOnce()) { logLine("auto-start ok (attempt " + std::to_string(attempt) + ")"); break; }
        logLine("auto-start attempt " + std::to_string(attempt) + " failed: " + g_err);
        if (g_javaFailed) break;
        for (int i = 0; i < 100 && !g_quit; ++i) std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    if (JavaVM* vm = aml->GetJavaVM()) vm->DetachCurrentThread();
}

} // namespace

extern "C" {

#define HX_EXPORT __attribute__((visibility("default")))

// Optional manual control (only needed if auto-start fails and you use the small Lua helper).
HX_EXPORT int hx_rpc_start()               { return startOnce(); }
HX_EXPORT const char* hx_rpc_error()       { return g_err; }
HX_EXPORT const char* hx_rpc_probe()       { return g_probe.c_str(); }
HX_EXPORT void hx_rpc_resync()             { std::lock_guard<std::mutex> l(g_mu); if (g_api) g_api->resync(); }
HX_EXPORT int hx_rpc_flags()               { std::lock_guard<std::mutex> l(g_mu); return g_api ? g_api->flags() : 0; }
HX_EXPORT int hx_rpc_status(char* out, int cap) {
    std::lock_guard<std::mutex> l(g_mu);
    if (g_api) return g_api->status(out, cap);
    if (out && cap > 0) std::snprintf(out, static_cast<size_t>(cap), "%s", g_err);
    return 0;
}

} // extern "C"

ON_MOD_LOAD() {
    g_boot = std::thread(bootThread);
    g_boot.detach();
}

ON_MOD_UNLOAD() {
    g_quit = true;
    std::lock_guard<std::mutex> l(g_mu);
    if (g_api) g_api->stop();
}
