// Hexed Discord RPC - AML mod (libDiscord_RPC.so)
// This is the only file AML loads, and the only file you install (plus the Lua script). It contains the
// Discord SDK, the core and the dex as embedded data and has no link dependency on the SDK:
//   1. unpacks the embedded support files into the app's private folder  <filesDir>/hxrpc
//   2. builds a DexClassLoader with the SDK's Java classes + HxBridge
//   3. HxBridge gives the SDK the game's Activity and System.load()s the SDK and the core through that loader
//   4. fetches the core's function table and exposes it to Lua over plain C (FFI)

#include "mod/amlmod.h"
#include <jni.h>
#include <android/log.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>
#include "api.h"

#ifndef HX_DEFAULT_APP_ID
#define HX_DEFAULT_APP_ID 0ULL
#endif

#define TAG "HexedRPC"

// embedded by payload.S
extern "C" {
extern const unsigned char hx_blob_sdk[] __attribute__((visibility("hidden")));
extern const unsigned char hx_blob_sdk_end[] __attribute__((visibility("hidden")));
extern const unsigned char hx_blob_core[] __attribute__((visibility("hidden")));
extern const unsigned char hx_blob_core_end[] __attribute__((visibility("hidden")));
extern const unsigned char hx_blob_dex[] __attribute__((visibility("hidden")));
extern const unsigned char hx_blob_dex_end[] __attribute__((visibility("hidden")));
}

MYMOD(net.hexedstudio.discordrpc, Hexed Discord RPC, 3.0.0, HEXED Studio)

namespace {

std::mutex g_mu;
bool g_javaFailed = false;   // Java stage failed: a second try in the same process cannot work, needs a game restart
HxApi* g_api = nullptr;
char g_err[512] = "not started";
std::string g_work;          // <filesDir>/hxrpc, also where the saved Discord login and the log live
std::string g_logPath;

jclass g_bridge = nullptr;   // HxBridge (global ref)
jobject g_ctx = nullptr;     // the Activity / Context handed to HxBridge (global ref)
jmethodID g_clipGet = nullptr;
jmethodID g_clipSet = nullptr;

void logLine(const std::string& s) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", s.c_str());
    if (g_logPath.empty()) return;
    if (FILE* f = std::fopen(g_logPath.c_str(), "a")) {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);
        char ts[16];
        std::strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        std::fprintf(f, "%s stub  %s\n", ts, s.c_str());
        std::fclose(f);
    }
}

void setErr(const std::string& s) {
    std::snprintf(g_err, sizeof(g_err), "%s", s.c_str());
    logLine("ERROR: " + s);
}

// Java-stage failure: remember it, a retry would only hit "Could not initialize class"
bool failJava(const std::string& s) {
    g_javaFailed = true;
    setErr(s + " (restart the game after fixing this)");
    return false;
}

// ---------------------------------------------------------------- embedded support files

const char* const kSdk  = "libdiscord_partner_sdk.so";
const char* const kCore = "libhxrpc_core.so";
const char* const kDex  = "hx_dex.jar";

struct Blob {
    const char* name;
    const unsigned char* begin;
    const unsigned char* end;
    mode_t mode;
    size_t size() const { return static_cast<size_t>(end - begin); }
};

const Blob* blobs() {
    static const Blob b[] = {
        { kSdk,  hx_blob_sdk,  hx_blob_sdk_end,  0555 },
        { kCore, hx_blob_core, hx_blob_core_end, 0555 },
        { kDex,  hx_blob_dex,  hx_blob_dex_end,  0444 },   // read-only: Android 14 refuses writable dex files
    };
    return b;
}
const int kBlobCount = 3;

uint64_t fnv1a(const unsigned char* p, size_t n, uint64_t h) {
    for (size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}

std::string readSmall(const std::string& path) {
    std::string out;
    if (FILE* f = std::fopen(path.c_str(), "r")) {
        char b[256];
        size_t n = std::fread(b, 1, sizeof(b) - 1, f);
        b[n] = 0;
        out = b;
        std::fclose(f);
    }
    return out;
}

bool fileSizeIs(const std::string& path, size_t size) {
    struct stat st{};
    return stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode) && static_cast<size_t>(st.st_size) == size;
}

// "" = ok, otherwise what went wrong (with errno)
std::string writeBlob(const std::string& path, const Blob& b) {
    unlink(path.c_str());   // may be read-only
    FILE* out = std::fopen(path.c_str(), "wb");
    if (!out) return "cannot write " + path + " (" + std::strerror(errno) + ")";
    const bool ok = std::fwrite(b.begin, 1, b.size(), out) == b.size();
    const std::string e = std::strerror(errno);
    if (std::fclose(out) != 0 || !ok) return "write failed for " + path + " (" + e + ")";
    chmod(path.c_str(), b.mode);
    return "";
}

// unpack when missing or when the embedded data changed (checksum), otherwise keep the files as they are
std::string extractPayload(const std::string& dir) {
    uint64_t h = 1469598103934665603ULL;
    for (int i = 0; i < kBlobCount; ++i) h = fnv1a(blobs()[i].begin, blobs()[i].size(), h);
    char sig[64];
    std::snprintf(sig, sizeof(sig), "%016llx", static_cast<unsigned long long>(h));

    bool current = readSmall(dir + "/payload.sig") == sig;
    for (int i = 0; current && i < kBlobCount; ++i)
        current = fileSizeIs(dir + "/" + blobs()[i].name, blobs()[i].size());
    if (current) return "";

    logLine("unpacking support files into " + dir);
    for (int i = 0; i < kBlobCount; ++i) {
        const std::string e = writeBlob(dir + "/" + blobs()[i].name, blobs()[i]);
        if (!e.empty()) return e;
    }
    unlink((dir + "/payload.sig").c_str());
    if (FILE* f = std::fopen((dir + "/payload.sig").c_str(), "w")) { std::fputs(sig, f); std::fclose(f); }
    // the DexClassLoader writes optimized code into odex/: stale output from an older dex must go
    unlink((dir + "/odex/hx_dex.dex").c_str());
    return "";
}

// ---------------------------------------------------------------- JNI helpers

JNIEnv* jenv() {
    JavaVM* vm = aml->GetJavaVM();
    if (!vm) return nullptr;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) return env;
    if (vm->AttachCurrentThread(&env, nullptr) == JNI_OK) return env;
    return nullptr;
}

// description of a pending Java exception, then clear it
std::string takeException(JNIEnv* env) {
    if (!env->ExceptionCheck()) return "";
    jthrowable t = env->ExceptionOccurred();
    env->ExceptionClear();
    std::string out = "Java exception";
    jclass tc = env->FindClass("java/lang/Throwable");
    jmethodID ts = env->GetMethodID(tc, "toString", "()Ljava/lang/String;");
    if (ts && t) {
        jstring js = (jstring)env->CallObjectMethod(t, ts);
        if (js) {
            const char* c = env->GetStringUTFChars(js, nullptr);
            if (c) { out = c; env->ReleaseStringUTFChars(js, c); }
        }
    }
    env->ExceptionClear();
    return out;
}

std::string javaString(JNIEnv* env, jobject obj, const char* method) {
    jclass c = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(c, method, "()Ljava/lang/String;");
    if (!m) { env->ExceptionClear(); return ""; }
    jstring s = (jstring)env->CallObjectMethod(obj, m);
    if (!s) return "";
    const char* c8 = env->GetStringUTFChars(s, nullptr);
    std::string r = c8 ? c8 : "";
    if (c8) env->ReleaseStringUTFChars(s, c8);
    return r;
}

bool bootstrap() {
    JNIEnv* env = jenv();
    if (!env) { setErr("no JNIEnv (AML gave no JavaVM / attach failed)"); return false; }

    // the game's Activity if AML has one (the SDK needs a real Activity to open links), else the app context
    jobject act = aml->GetCurrentActivity();
    jobject ctx = act ? act : aml->GetCurrentContext();
    if (!ctx) { setErr("no Activity / context from AML"); return false; }
    logLine(std::string("AML handed over an ") + (act ? "Activity" : "app Context"));

    // --- private working dir: <filesDir>/hxrpc
    jclass ctxCls = env->GetObjectClass(ctx);
    jmethodID getFiles = env->GetMethodID(ctxCls, "getFilesDir", "()Ljava/io/File;");
    jobject filesDir = getFiles ? env->CallObjectMethod(ctx, getFiles) : nullptr;
    if (!filesDir) { setErr("getFilesDir failed: " + takeException(env)); return false; }
    const std::string work = javaString(env, filesDir, "getAbsolutePath") + "/hxrpc";
    mkdir(work.c_str(), 0700);
    mkdir((work + "/odex").c_str(), 0700);
    g_work = work;
    g_logPath = work + "/hxrpc.log";
    {   // keep the log small: start a fresh one when it grew past 256 KB
        struct stat st{};
        if (stat(g_logPath.c_str(), &st) == 0 && st.st_size > 256 * 1024) unlink(g_logPath.c_str());
    }
    logLine("bootstrap, work dir " + work);

    // --- unpack the embedded SDK, core and dex (not a Java failure: can be retried)
    const std::string ex = extractPayload(work);
    if (!ex.empty()) { setErr(ex); return false; }

    // --- DexClassLoader(dexPath, odexDir, libDir, parent = the game's loader)
    jmethodID getLoader = env->GetMethodID(ctxCls, "getClassLoader", "()Ljava/lang/ClassLoader;");
    jobject parent = env->CallObjectMethod(ctx, getLoader);
    jclass dcl = env->FindClass("dalvik/system/DexClassLoader");
    jmethodID dclInit = env->GetMethodID(dcl, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
    jstring jDex = env->NewStringUTF((work + "/" + kDex).c_str());
    jstring jOpt = env->NewStringUTF((work + "/odex").c_str());
    jstring jLib = env->NewStringUTF(work.c_str());
    jobject loader = env->NewObject(dcl, dclInit, jDex, jOpt, jLib, parent);
    if (!loader) return failJava("DexClassLoader: " + takeException(env));

    jmethodID loadClass = env->GetMethodID(dcl, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    jstring jName = env->NewStringUTF("com.hexed.rpc.HxBridge");
    jclass bridge = (jclass)env->CallObjectMethod(loader, loadClass, jName);
    if (!bridge) return failJava("loadClass HxBridge: " + takeException(env));
    bridge = (jclass)env->NewGlobalRef(bridge);

    // --- HxBridge.init(ctx, sdkPath, corePath)
    jmethodID init = env->GetStaticMethodID(bridge, "init",
        "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    if (!init) return failJava("HxBridge.init not found: " + takeException(env));
    jstring jSdk  = env->NewStringUTF((work + "/" + kSdk).c_str());
    jstring jCore = env->NewStringUTF((work + "/" + kCore).c_str());
    jstring res = (jstring)env->CallStaticObjectMethod(bridge, init, ctx, jSdk, jCore);
    if (env->ExceptionCheck()) return failJava("HxBridge.init: " + takeException(env));
    if (res) {
        const char* c = env->GetStringUTFChars(res, nullptr);
        const std::string msg = std::string("HxBridge.init: ") + (c ? c : "?");
        if (c) env->ReleaseStringUTFChars(res, c);
        return failJava(msg);
    }

    // --- HxBridge.apiTable() -> function table inside the core
    jmethodID tbl = env->GetStaticMethodID(bridge, "apiTable", "()J");
    jlong addr = tbl ? env->CallStaticLongMethod(bridge, tbl) : 0;
    if (env->ExceptionCheck()) return failJava("apiTable: " + takeException(env));
    g_api = reinterpret_cast<HxApi*>(static_cast<intptr_t>(addr));
    if (!g_api || g_api->version != HX_API_VERSION) { g_api = nullptr; return failJava("core API mismatch"); }

    // --- clipboard helpers (optional: login still works without them, the user then has to type)
    g_bridge = bridge;
    g_ctx = env->NewGlobalRef(ctx);
    g_clipGet = env->GetStaticMethodID(bridge, "clipGet", "(Landroid/content/Context;)Ljava/lang/String;");
    g_clipSet = env->GetStaticMethodID(bridge, "clipSet", "(Landroid/content/Context;Ljava/lang/String;)Z");
    env->ExceptionClear();

    std::snprintf(g_err, sizeof(g_err), "ok");
    logLine("bootstrap ok");
    return true;
}

HxApi* api() {
    std::lock_guard<std::mutex> lock(g_mu);
    return g_api;
}

} // namespace

extern "C" {

#define HX_EXPORT __attribute__((visibility("default")))

// ---- exported for Lua (ffi.load) -------------------------------------------------------------
// returns 1 on success; on failure hx_rpc_error() says why. Safe to call again after a file problem.
// appId: decimal string, "" = built-in default.
HX_EXPORT int hx_rpc_start(const char* appId) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        if (!g_api) {
            if (g_javaFailed) return 0;          // error text stays; needs a game restart
            if (!bootstrap()) return 0;          // file problems are retried on the next call
        }
    }
    unsigned long long id = (appId && *appId) ? std::strtoull(appId, nullptr, 10) : HX_DEFAULT_APP_ID;
    if (id == 0) { setErr("no Discord application id"); return 0; }
    return g_api->start(id, g_work.c_str());
}
HX_EXPORT const char* hx_rpc_error() { return g_err; }
HX_EXPORT const char* hx_rpc_work_dir() { return g_work.c_str(); }
HX_EXPORT void hx_rpc_stop()         { if (auto* a = api()) a->stop(); }
HX_EXPORT void hx_rpc_clear()        { if (auto* a = api()) a->clear(); }
HX_EXPORT void hx_rpc_login()        { if (auto* a = api()) a->login(); }
HX_EXPORT void hx_rpc_login_device() { if (auto* a = api()) a->loginDevice(); }
HX_EXPORT void hx_rpc_logout()       { if (auto* a = api()) a->logout(); }
HX_EXPORT int  hx_rpc_login_url(char* out, int cap) { if (auto* a = api()) return a->loginUrl(out, cap); return 0; }
HX_EXPORT void hx_rpc_login_finish(const char* pasted) { if (auto* a = api()) a->loginFinish(pasted); }
HX_EXPORT void hx_rpc_set_state(const char* nick, int id, const char* server,
                                const char* ip, int port, int players, long long start) {
    if (auto* a = api()) a->setState(nick, id, server, ip, port, players, start);
}
HX_EXPORT int hx_rpc_status(char* out, int cap) {
    if (auto* a = api()) return a->status(out, cap);
    if (out && cap > 0) std::snprintf(out, static_cast<size_t>(cap), "%s", g_err);
    return 0;
}
HX_EXPORT int hx_rpc_flags() {
    if (auto* a = api()) return a->flags();
    return 0;
}

// text on the clipboard -> out. Returns the length, 0 when empty or not available.
HX_EXPORT int hx_rpc_clipboard_get(char* out, int cap) {
    if (!out || cap <= 0) return 0;
    out[0] = 0;
    if (!g_bridge || !g_clipGet) return 0;
    JNIEnv* env = jenv();
    if (!env) return 0;
    jstring s = (jstring)env->CallStaticObjectMethod(g_bridge, g_clipGet, g_ctx);
    if (env->ExceptionCheck()) { logLine("clipboard read: " + takeException(env)); return 0; }
    if (!s) return 0;
    const char* c = env->GetStringUTFChars(s, nullptr);
    if (c) {
        std::snprintf(out, static_cast<size_t>(cap), "%s", c);
        env->ReleaseStringUTFChars(s, c);
    }
    env->DeleteLocalRef(s);
    return static_cast<int>(std::strlen(out));
}

// copy text to the clipboard. Returns 1 on success.
HX_EXPORT int hx_rpc_clipboard_set(const char* text) {
    if (!g_bridge || !g_clipSet || !text) return 0;
    JNIEnv* env = jenv();
    if (!env) return 0;
    jstring js = env->NewStringUTF(text);
    jboolean ok = env->CallStaticBooleanMethod(g_bridge, g_clipSet, g_ctx, js);
    env->DeleteLocalRef(js);
    if (env->ExceptionCheck()) { logLine("clipboard write: " + takeException(env)); return 0; }
    return ok ? 1 : 0;
}

} // extern "C"

ON_MOD_UNLOAD() {
    if (auto* a = api()) a->stop();
}
