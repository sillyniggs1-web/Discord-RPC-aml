# Hexed Discord RPC - native AML mod (v4.0, no login)

**v4 removes the whole Discord login.** No browser, no `http://localhost/callback`, no copy-the-address step, no tokens.
The presence is handed to the **Discord app installed on the same phone**, which publishes it to your profile - the same
way the ReSA Multiplayer APK does it. The Discord app must be installed, **signed in**, and running (background is fine).

```
SA-MP client -> Discord_RPC.lua (menu, game info) -> FFI -> libDiscord_RPC.so (AML mod)
   -> core + Discord Social SDK (SetApplicationId + UpdateRichPresence, nothing else)
   -> SDK Java class DiscordRpcClient -> bindService(com.discord / IDiscordRpcService) -> Discord app -> your profile
```

## Install (same layout as v3.x)
Nezuko is 32-bit, use the **armeabi-v7a** folder of the build.
```
<AML mods folder>/libDiscord_RPC.so
<AML mods folder>/Discord_RPC/                 <- keep this folder next to the .so
        libhxrpc_core_v4.so
        libdiscord_partner_sdk.so
        hx_dex_v3.jar
<MonetLoader scripts folder>/Discord_RPC.lua
```
Replace the whole `Discord_RPC/` folder, the `.so` and the Lua script together (v3 files are ignored: the core and dex got new names).
The old saved login (`files/hxrpc/discord_login.txt`) is no longer used; you can delete it.

## Build (GitHub)
Same as before: push the folder, run **Actions -> Build Discord_RPC AML mod**, download the `Discord_RPC_AML` artifact.
`-DHX_APP_ID=<id>` changes the built-in application id.

## Discord developer portal
Nothing about OAuth any more: no redirect URL, no Public Client, no User Install.
The application id (1566671569479147600) is only used to label the game and to find the **Art Assets** (`samp_logo`, App Icon).

## Menu
`/drpc` - status card, **Discord app** card with *Retry connection*, presence settings, Diagnostics.
`/rpcdebug` prints the status in chat, `/rpctoggle` flips presence on/off, `/rpcreload` re-reads `Hexed DiscordRpc.ini`.
Diagnostics shows one extra line, **discord app:** - what this process can see of the Discord app (see below). **Copy diagnostics**
puts it plus the log tail on the clipboard. Full log: `files/hxrpc/hxrpc.log` (logcat tag `HexedRPC`).

## If it says "OPEN DISCORD APP" / "Discord app not reachable"
1. Discord app installed and signed in? Open it once, then press **Retry connection**.
2. Look at the `discord app:` diagnostics line / the first lines of `hxrpc.log` (`probe: ...`):
   * `discord=not visible` + `targetSdk=30` or higher: Android 11+ hides other apps from a game that has no `<queries>`
     entry for `com.discord`, and a mod cannot add one to Nezuko's manifest. The SDK then reports "Discord client not installed".
   * `rpcService=NOT FOUND` while `discord=visible`: the installed Discord app is too old / does not offer the SDK's RPC service.
   * `rpcService=... (exported)` but still not reachable: send `hxrpc.log` (it contains the SDK's own RPC lines).

## Status: written without a toolchain or a device
Checked on the host: `core.cpp` compiles against the real `discordpp.h`; `stub.cpp` compiles against the AML headers and a real `jni.h`;
`HxBridge.java` compiles against stub Android classes plus the real SDK jar; the Lua script compiles under LuaJIT, its FFI declarations
parse and match the stub's exports one to one.
NOT checked: the NDK/CMake build, the d8 step, Lua at runtime, and everything on a phone - in particular whether the Discord app accepts the
RPC binding from inside Nezuko's process (it works for the ReSA APK, which declares `<queries>` for `com.discord`).

## What changed from v3.5
| | |
|---|---|
| Removed | OAuth/PKCE browser login, token exchange/refresh, saved login file, device-code login, clipboard-paste step, `Log in` / `Log out` / `Finish login` buttons, localhost redirect |
| Kept | AML stub + core split, dex class loader, `HxBridge` (Activity for the SDK), presence look (`[presence]` INI, placeholders, images, party, timer, buttons), diagnostics, log file |
| Added | `HxBridge.probe()` (can this process see the Discord app and its RPC service), automatic retry every 8 s while the Discord app is not reachable, `Retry connection` button, API v4 |
