// Function table shared by the stub (libDiscord_RPC.so) and the core (libhxrpc_core_v4.so).
// The stub gets the table's address from HxBridge.apiTable() after the Java side loaded the core.
// v4: no login at all - presence is handed to the Discord app installed on the phone (Social SDK "RPC" path).
#pragma once
#define HX_API_VERSION 4
// Presence look, filled from the Lua INI. Every string may use {server} {nick} {id} {ip} {port} {players}.
// flags: bit0 party "(x of y)", bit1 buttons, bit2 elapsed timer, bit3 small image, bit4 (16) set the activity name from the script (0 = Discord uses the registered application name).
struct HxExtras {
    const char* detailsTpl;
    const char* stateTpl;
    const char* largeImage;   // Rich Presence art asset key or https URL ("" = none)
    const char* largeText;
    const char* smallImage;
    const char* smallText;
    const char* btn1Label; const char* btn1Url;
    const char* btn2Label; const char* btn2Url;
    int maxPlayers;
    int flags;
};
// flags(): bit0 = the Discord app accepted the last presence, bit1 = core running, bit2 = retrying (Discord app not reachable)
struct HxApi {
    int  version;
    int  (*start)(unsigned long long appId, const char* dir);
    void (*stop)();
    void (*setState)(const char* nick, int id, const char* server, const char* ip, int port, int players, long long start);
    void (*clear)();
    void (*resync)();                         // push the presence again right now (menu: "Retry connection")
    int  (*status)(char* out, int cap);
    int  (*flags)();
    void (*setExtras)(const HxExtras* e);
};
