// Hexed Discord RPC - core library (libhxrpc_core_v4.so)                                    [v4: no login]
// Discord Social SDK + rich presence, WITHOUT any Discord login, token, browser step or localhost redirect.
// Loaded through the dex class loader by HxBridge, so it shares one copy of libdiscord_partner_sdk.so (and
// its JNI state) with the SDK's Java classes.
//
// How the presence reaches Discord (same way the ReSA Multiplayer APK does it):
//   Client::SetApplicationId(appId) + Client::UpdateRichPresence(activity)   - and nothing else.
//   No UpdateToken / Connect / Authorize: the SDK's RPC layer (rpc_manager / rpc_connection_android) then binds
//   to the Discord Android app's IPC service (com.discord.socialsdk.rpc.IDiscordRpcService) through the SDK's
//   Java class com.discord.socialsdk.DiscordRpcClient and sends the activity to it. The Discord app on the same
//   phone - already logged in by the user - publishes it to the user's profile.
// Requirement: the Discord app is installed, logged in and (at least in the background) running.
// No UDP socket: the Lua script pushes the game state straight in through the stub (libDiscord_RPC.so).

#define DISCORDPP_IMPLEMENTATION // exactly one file
#include "discordpp.h"

#include <jni.h>
#include <android/log.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "api.h"

#define TAG "HexedRPC"

namespace {

const long long kRetryMs = 8000;      // pause between attempts while the Discord app is not reachable

std::atomic<bool> g_run{false};
std::thread g_thread;
std::mutex g_mu;              // guards g_status, g_state, g_look
std::string g_status = "Stopped";
std::string g_logPath;

std::atomic<bool> g_ready{false};        // the Discord app accepted the last presence
std::atomic<bool> g_retry{false};        // last attempt failed: try again at g_retryAtMs
std::atomic<long long> g_retryAtMs{0};
std::atomic<bool> g_resync{false};       // menu "Retry connection"

struct State {
    bool active = false;
    std::string nick, server, ip;
    int port = 7777;
    int players = 0;
    int id = -1;
    long long start = 0;
};
State g_state;
struct Look {
    std::string details = "{server}", state = "{nick} \xE2\x80\xA2 {ip}:{port}";
    std::string largeImage, largeText = "{server}", smallImage, smallText = "{nick} (ID {id})";
    std::string b1l, b1u, b2l, b2u;
    int maxPlayers = 1000;
    int flags = 1 | 4;
};
Look g_look;                       // guarded by g_mu
std::atomic<int> g_lookVer{0};
std::atomic<unsigned long long> g_appId{0};
std::atomic<long long> g_lastSetMs{0};   // steady-clock ms of the last state pushed by Lua

long long nowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

void logLine(const std::string& s) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", s.c_str());
    if (g_logPath.empty()) return;
    if (FILE* f = std::fopen(g_logPath.c_str(), "a")) {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);
        char ts[16];
        std::strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        std::fprintf(f, "%s core  %s\n", ts, s.c_str());
        std::fclose(f);
    }
}

// logs only when the text changes (the presence is re-sent every 30 s, the log must not fill up with "Presence active")
void setStatus(const std::string& s) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        if (g_status == s) return;
        g_status = s;
    }
    logLine(s);
}

std::string clip(const std::string& s, size_t max) {
    if (s.size() <= max) return s;
    size_t n = max;
    while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;
    return s.substr(0, n);
}

std::string trim(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && (s[b] == ' ' || s[b] == '\t' || s[b] == '\r' || s[b] == '\n')) ++b;
    while (e > b && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n')) --e;
    return s.substr(b, e - b);
}

// ---------------------------------------------------------------- presence

std::string expand(const std::string& tpl, const State& s) {
    std::string out;
    for (size_t i = 0; i < tpl.size();) {
        if (tpl[i] == '{') {
            const size_t e = tpl.find('}', i);
            if (e != std::string::npos) {
                const std::string k = tpl.substr(i + 1, e - i - 1);
                const char* v = nullptr;
                std::string tmp;
                if (k == "server") tmp = s.server.empty() ? std::string("SA-MP server") : s.server;
                else if (k == "nick") tmp = s.nick.empty() ? std::string("player") : s.nick;
                else if (k == "ip") tmp = s.ip;
                else if (k == "port") tmp = std::to_string(s.port);
                else if (k == "players") tmp = std::to_string(s.players);
                else if (k == "id") tmp = std::to_string(s.id);
                else v = "";
                if (v == nullptr) { out += tmp; i = e + 1; continue; }
            }
        }
        out += tpl[i++];
    }
    return out;
}

void push(const std::shared_ptr<discordpp::Client>& client, const State& s) {
    if (!s.active) {
        client->ClearRichPresence();
        g_retry = false;
        setStatus("Presence cleared (not in a server)");
        return;
    }
    Look L;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        L = g_look;
    }

    discordpp::Activity a;
    a.SetType(discordpp::ActivityTypes::Playing);
    a.SetName("San Andreas Multiplayer");
    // the registered game: this is what makes Discord show the game icon in the voice channel member list
    a.SetApplicationId(g_appId.load());
    a.SetStatusDisplayType(discordpp::StatusDisplayTypes::Name);
    a.SetSupportedPlatforms(static_cast<discordpp::ActivityGamePlatforms>(
        static_cast<int>(discordpp::ActivityGamePlatforms::Desktop) |
        static_cast<int>(discordpp::ActivityGamePlatforms::Android) |
        static_cast<int>(discordpp::ActivityGamePlatforms::IOS)));
    a.SetDetails(clip(expand(L.details, s), 120));
    a.SetState(clip(expand(L.state, s), 120));

    const std::string largeImg = trim(L.largeImage);
    const std::string smallImg = trim(L.smallImage);
    const bool useLarge = !largeImg.empty() && largeImg.size() <= 300;   // SDK limit: 1..300 characters
    const bool useSmall = (L.flags & 8) && !smallImg.empty() && smallImg.size() <= 300;
    {   // one log line per change: what exactly goes to the Discord app (the log is the only way to see why an image is missing)
        static std::string lastAssets;
        const std::string now = "assets: app=" + std::to_string(g_appId.load()) + " large=" + (useLarge ? largeImg : std::string("(none)")) +
                                " small=" + (useSmall ? smallImg : std::string("(none)")) +
                                (!largeImg.empty() && !useLarge ? " [large image longer than 300 chars: not sent]" : "");
        if (now != lastAssets) { lastAssets = now; logLine(now); }
    }
    if (useLarge || useSmall) {
        discordpp::ActivityAssets as;
        if (useLarge) {
            as.SetLargeImage(largeImg);
            const std::string lt = clip(expand(L.largeText, s), 120);
            if (lt.size() >= 2) as.SetLargeText(lt);   // SDK limit: 2..128 characters
        }
        if (useSmall) {
            as.SetSmallImage(smallImg);
            const std::string st = clip(expand(L.smallText, s), 120);
            if (st.size() >= 2) as.SetSmallText(st);
        }
        a.SetAssets(as);
    }
    if ((L.flags & 4) && s.start > 0) {
        discordpp::ActivityTimestamps ts;
        ts.SetStart(static_cast<uint64_t>(s.start));
        a.SetTimestamps(ts);
    }
    if ((L.flags & 1) && s.players > 0) {
        discordpp::ActivityParty party;
        party.SetId(s.ip + ":" + std::to_string(s.port));
        party.SetCurrentSize(s.players);
        party.SetMaxSize(L.maxPlayers > s.players ? L.maxPlayers : s.players);
        a.SetParty(party);
    }
    if (L.flags & 2) {
        auto addBtn = [&](const std::string& label, const std::string& url) {
            if (label.empty() || url.compare(0, 4, "http") != 0) return;
            discordpp::ActivityButton b;
            b.SetLabel(clip(label, 32));
            b.SetUrl(url);
            a.AddButton(b);
        };
        addBtn(L.b1l, L.b1u);
        addBtn(L.b2l, L.b2u);
    }
    client->UpdateRichPresence(a, [](discordpp::ClientResult r) {
        if (r.Successful()) {
            g_ready = true;
            g_retry = false;
            setStatus("Presence active");
        } else {
            // the Discord app did not take it: not installed / not running / no permission to bind its service
            g_ready = false;
            g_retry = true;
            g_retryAtMs = nowMs() + kRetryMs;
            setStatus("Discord app not reachable (retrying): " + std::string(r.Error()));
        }
    });
}


// ---------------------------------------------------------------- worker thread

void worker(uint64_t appId) {
    using clock = std::chrono::steady_clock;
    using std::chrono::seconds;

    auto client = std::make_shared<discordpp::Client>();
    // the SDK's own log lines (RPC connect / "Activity set successfully over RPC" / errors) go to hxrpc.log
    client->AddLogCallback([](auto message, auto) { logLine("[sdk] " + std::string(message)); },
                           discordpp::LoggingSeverity::Info);

    // the only SDK setup the RPC path needs
    client->SetApplicationId(appId);
    setStatus("Ready. Waiting for the SA-MP server (presence goes to the Discord app on this phone)");

    std::string lastKey;
    auto lastPush = clock::time_point{};

    while (g_run) {
        State cur;
        {
            std::lock_guard<std::mutex> lock(g_mu);
            // the Lua side refreshes the state about every second; 10 s of silence means "left the server"
            if (g_state.active && nowMs() - g_lastSetMs.load() > 10000) g_state = State{};
            cur = g_state;
        }
        const auto now = clock::now();

        const std::string key = cur.active
            ? cur.server + "|" + cur.ip + ":" + std::to_string(cur.port) + "|" + cur.nick + "|" + std::to_string(cur.start) +
              "|" + std::to_string(cur.players) + "|" + std::to_string(g_lookVer.load())
            : std::string();

        bool due = key != lastKey || (cur.active && now - lastPush > seconds(30));
        if (g_resync.exchange(false)) { due = true; g_retry = false; }
        if (g_retry && nowMs() >= g_retryAtMs.load()) { due = true; g_retry = false; }   // Discord app was not there: try again

        if (due) {
            push(client, cur);
            lastKey = key;
            lastPush = now;
        }
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    client->ClearRichPresence();
    for (int i = 0; i < 5; ++i) {
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

} // namespace

// ---------------------------------------------------------------- function table (HxApi)

static int c_start(unsigned long long appId, const char* dir) {
    if (g_run.exchange(true)) return 1;
    const std::string d = dir ? dir : ".";
    g_logPath = d + "/hxrpc.log";
    g_ready = false; g_retry = false; g_resync = false;
    if (g_thread.joinable()) g_thread.join();
    g_appId = appId;
    logLine("core start (no-login mode), app id " + std::to_string(appId));
    g_thread = std::thread(worker, static_cast<uint64_t>(appId));
    return 1;
}

static void c_stop() {
    g_run = false;
    if (g_thread.joinable()) g_thread.join();
    g_ready = false;
    setStatus("Stopped");
}

static void c_set_state(const char* nick, int id, const char* server, const char* ip, int port, int players, long long start) {
    std::lock_guard<std::mutex> lock(g_mu);
    g_state.active = true;
    g_state.nick = nick ? nick : "";
    g_state.server = server ? server : "";
    g_state.ip = ip ? ip : "";
    g_state.port = port;
    g_state.players = players;
    g_state.id = id;
    g_state.start = start;
    g_lastSetMs = nowMs();
}

static void c_clear() {
    std::lock_guard<std::mutex> lock(g_mu);
    g_state = State{};
}

static void c_resync() { g_resync = true; }

static int c_status(char* out, int cap) {
    if (!out || cap <= 0) return 0;
    std::lock_guard<std::mutex> lock(g_mu);
    std::snprintf(out, static_cast<size_t>(cap), "%s", g_status.c_str());
    return static_cast<int>(std::strlen(out));
}

static int c_flags() {
    int f = 0;
    if (g_ready) f |= 1;
    if (g_run) f |= 2;
    if (g_retry) f |= 4;
    return f;
}

static void c_set_extras(const HxExtras* e) {
    if (!e) return;
    auto S = [](const char* p) { return std::string(p ? p : ""); };
    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_look.details = S(e->detailsTpl);
        g_look.state = S(e->stateTpl);
        g_look.largeImage = S(e->largeImage);
        g_look.largeText = S(e->largeText);
        g_look.smallImage = S(e->smallImage);
        g_look.smallText = S(e->smallText);
        g_look.b1l = S(e->btn1Label); g_look.b1u = S(e->btn1Url);
        g_look.b2l = S(e->btn2Label); g_look.b2u = S(e->btn2Url);
        g_look.maxPlayers = e->maxPlayers;
        g_look.flags = e->flags;
    }
    ++g_lookVer;   // changes the presence key: the worker pushes again at once
}

static HxApi g_api = { HX_API_VERSION, c_start, c_stop, c_set_state, c_clear, c_resync, c_status, c_flags, c_set_extras };

// Reached through HxBridge.apiTable() once the Java side has System.load()ed this library.
extern "C" JNIEXPORT jlong JNICALL Java_com_hexed_rpc_HxBridge_apiTable(JNIEnv*, jclass) {
    return static_cast<jlong>(reinterpret_cast<intptr_t>(&g_api));
}
