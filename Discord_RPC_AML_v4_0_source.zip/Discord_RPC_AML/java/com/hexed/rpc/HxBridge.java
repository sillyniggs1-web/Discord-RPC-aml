package com.hexed.rpc;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * Loaded by the stub through a DexClassLoader together with the Discord Social SDK classes.
 * Does the things the SDK needs from Java inside another app's process:
 *  - System.load()s the SDK by its absolute path first (a linker problem is then reported with its real
 *    reason instead of "library not found").
 *  - hands it the game's Activity (DiscordSocialSdkInit.setEngineActivity)
 *  - System.load()s the core library from THIS class loader, so the SDK and the core share one copy of
 *    libdiscord_partner_sdk.so and the same JNI class cache.
 * Also offers a clipboard write (diagnostics) and probe(): does this process see the Discord app and its RPC service.
 */
public final class HxBridge {
    private HxBridge() {}

    private static String reflectError = "";

    /** Implemented in libhxrpc_core.so; returns the address of its HxApi function table. */
    public static native long apiTable();

    /** Returns null on success, otherwise a description of what failed. */
    public static String init(Context ctx, String sdkPath, String corePath) {
        try {
            try {
                System.load(sdkPath);
            } catch (Throwable t) {
                return "load SDK (" + sdkPath + "): " + describe(t);
            }
            Activity act = findActivity(ctx);
            if (act == null) {
                return "no running Activity found (AML context: " + (ctx == null ? "null" : ctx.getClass().getName())
                        + (reflectError.isEmpty() ? "" : "; " + reflectError) + ")";
            }
            // the static initializer of DiscordSocialSdkInit calls System.loadLibrary("discord_partner_sdk"):
            // the library is already loaded from the same path by this loader, so that is a no-op
            com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(act);
            try {
                System.load(corePath);
            } catch (Throwable t) {
                return "load core (" + corePath + "): " + describe(t);
            }
            return null;
        } catch (Throwable t) {
            return describe(t);
        }
    }

    /**
     * One line describing whether this process can reach the Discord app's RPC service, for the log and the
     * Diagnostics panel. The Social SDK binds to com.discord.socialsdk.rpc.IDiscordRpcService of the "com.discord"
     * package; on Android 11+ (target SDK 30+) a host app that has no <queries> entry for it cannot see that package.
     */
    public static String probe(Context ctx) {
        StringBuilder sb = new StringBuilder();
        try {
            int target = ctx.getApplicationInfo().targetSdkVersion;
            sb.append("android=").append(Build.VERSION.SDK_INT).append(" host=").append(ctx.getPackageName())
              .append(" targetSdk=").append(target);
            PackageManager pm = ctx.getPackageManager();
            boolean visible = false;
            try {
                PackageInfo pi = pm.getPackageInfo("com.discord", 0);
                visible = true;
                sb.append(" discord=visible(").append(pi.versionName).append(")");
            } catch (PackageManager.NameNotFoundException e) {
                sb.append(" discord=not visible");
            }
            Intent i = new Intent("com.discord.socialsdk.rpc.IDiscordRpcService").setPackage("com.discord");
            ResolveInfo ri = pm.resolveService(i, 0);
            if (ri == null || ri.serviceInfo == null) {
                sb.append(" rpcService=NOT FOUND");
            } else {
                sb.append(" rpcService=").append(ri.serviceInfo.name)
                  .append(ri.serviceInfo.exported ? " (exported)" : " (not exported)");
            }
            if (!visible && target >= 30) {
                sb.append(" | HINT: either the Discord app is not installed, or this game targets Android 11+ and has no")
                  .append(" <queries> entry for com.discord, so Android hides it from the SDK");
            } else if (!visible) {
                sb.append(" | HINT: the Discord app is not installed on this phone");
            }
        } catch (Throwable t) {
            sb.append(" probe failed: ").append(describe(t));
        }
        return sb.toString();
    }

    public static boolean clipSet(Context ctx, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null) return false;
            cm.setPrimaryClip(ClipData.newPlainText("Hexed Discord RPC", text));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String describe(Throwable t) {
        String m = t.getClass().getSimpleName() + ": " + t.getMessage();
        Throwable c = t.getCause();
        if (c != null && c != t) m += " <- " + c.getClass().getSimpleName() + ": " + c.getMessage();
        return m;
    }

    private static Activity findActivity(Context ctx) {
        Context c = ctx;
        for (int i = 0; c != null && i < 10; i++) {
            if (c instanceof Activity) return (Activity) c;
            if (!(c instanceof ContextWrapper)) break;
            Context base = ((ContextWrapper) c).getBaseContext();
            if (base == c) break;
            c = base;
        }
        try {
            return findActivityReflect();
        } catch (Throwable t) {
            reflectError = "ActivityThread lookup: " + describe(t);
            return null;
        }
    }

    // last resort when AML hands over no Activity
    private static Activity findActivityReflect() throws Exception {
        Class<?> at = Class.forName("android.app.ActivityThread");
        Object thread = at.getMethod("currentActivityThread").invoke(null);
        Field f = at.getDeclaredField("mActivities");
        f.setAccessible(true);
        Map<?, ?> map = (Map<?, ?>) f.get(thread);
        if (map == null) return null;
        for (Object rec : map.values()) {
            Field af = rec.getClass().getDeclaredField("activity");
            af.setAccessible(true);
            Object a = af.get(rec);
            if (a instanceof Activity) return (Activity) a;
        }
        return null;
    }
}
