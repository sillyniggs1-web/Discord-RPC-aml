#!/usr/bin/env python3
"""Hexed Discord RPC - sign in OUTSIDE the game.

Runs on a PC, or on the phone itself in Termux (pkg install python). Standard library only.
It does the same Discord login the in-game "code" login does (OAuth2 authorization code + PKCE,
public client, no secret), then saves the refresh token to Discord_RPC_login.txt.
Put that file where the game can read it (see README) and start the game: nothing is opened
from inside the game, so nothing can crash it.

Needs, once, in the Discord developer portal (your application):
  - OAuth2 > Public Client = ON
  - OAuth2 > Redirects: add  http://localhost   (or the --redirect value you use)
"""
import argparse
import base64
import hashlib
import http.server
import json
import os
import secrets
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

DEFAULT_APP_ID = "1566671569479147600"
SCOPES = "openid sdk.social_layer_presence"      # = Client::GetDefaultPresenceScopes()
AUTH_URL = "https://discord.com/oauth2/authorize"
TOKEN_URL = "https://discord.com/api/v10/oauth2/token"
UA = "HexedRPC-Login/1.0"                        # Discord's edge rejects the default python UA


def b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def make_pkce():
    verifier = b64url(secrets.token_bytes(32))                       # 43 chars, RFC 7636
    challenge = b64url(hashlib.sha256(verifier.encode("ascii")).digest())
    return verifier, challenge


def build_auth_url(app_id, redirect, challenge, state):
    q = urllib.parse.urlencode({
        "client_id": app_id,
        "response_type": "code",
        "scope": SCOPES,
        "redirect_uri": redirect,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
    }, quote_via=urllib.parse.quote)
    return AUTH_URL + "?" + q


def extract_code(text, state):
    """Accepts the bare code or the whole address http://localhost/?code=XXXX&state=..."""
    text = text.strip()
    if "code=" not in text:
        return text, True
    parsed = urllib.parse.urlparse(text)
    qs = urllib.parse.parse_qs(parsed.query or text.split("?", 1)[-1])
    code = (qs.get("code") or [""])[0]
    got_state = (qs.get("state") or [None])[0]
    return code, (got_state is None or got_state == state)


def exchange(token_url, app_id, code, verifier, redirect):
    body = urllib.parse.urlencode({
        "client_id": app_id,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect,
        "code_verifier": verifier,
    }).encode("ascii")
    req = urllib.request.Request(token_url, data=body, method="POST", headers={
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
        "User-Agent": UA,
    })
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        raise SystemExit("Discord refused the code (HTTP %d): %s\n"
                         "Codes work once and expire after a few minutes - start again.\n"
                         "Also check: Public Client is ON and the redirect is registered exactly." % (e.code, detail))
    except urllib.error.URLError as e:
        raise SystemExit("Could not reach Discord: %s" % e.reason)


def wait_for_redirect(redirect, state):
    """If the redirect is http://localhost:PORT/..., catch the browser's visit automatically."""
    u = urllib.parse.urlparse(redirect)
    if u.hostname not in ("localhost", "127.0.0.1") or not u.port:
        return None
    result = {}
    done = threading.Event()

    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            result["url"] = "http://localhost" + self.path
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"Done. You can close this tab and go back to the terminal.")
            done.set()

        def log_message(self, *a):
            pass

    try:
        srv = http.server.HTTPServer(("127.0.0.1", u.port), H)
    except OSError as e:
        print("(could not listen on port %d: %s - falling back to copy/paste)" % (u.port, e))
        return None
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print("Waiting for the browser to come back to %s ... (Ctrl+C to paste manually)" % redirect)
    try:
        done.wait(300)
    except KeyboardInterrupt:
        pass
    srv.shutdown()
    return result.get("url")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--app-id", default=os.environ.get("HX_APP_ID", DEFAULT_APP_ID))
    ap.add_argument("--redirect", default="http://localhost")
    ap.add_argument("--out", default="Discord_RPC_login.txt")
    ap.add_argument("--token-url", default=TOKEN_URL, help=argparse.SUPPRESS)   # for tests
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()

    verifier, challenge = make_pkce()
    state = b64url(secrets.token_bytes(12))
    url = build_auth_url(a.app_id, a.redirect, challenge, state)

    print("\n1) Open this link, log in to Discord and press Authorize:\n\n" + url + "\n")
    if not a.no_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass

    pasted = wait_for_redirect(a.redirect, state)
    if not pasted:
        print("2) The browser ends on a 'site can't be reached' page. That is expected.")
        print("   Copy the full address from the address bar and paste it here.")
        pasted = input("\nAddress (or just the code): ")

    code, state_ok = extract_code(pasted, state)
    if not state_ok:
        raise SystemExit("The 'state' value does not match - this address is from a different login. Start again.")
    if not code:
        raise SystemExit("No code found in what you pasted.")

    tok = exchange(a.token_url, a.app_id, code, verifier, a.redirect)
    refresh = tok.get("refresh_token", "")
    if not refresh:
        raise SystemExit("Discord answered without a refresh token: %s" % json.dumps(tok)[:300])

    with open(a.out, "w", encoding="ascii") as f:
        f.write(refresh + "\n")
    try:
        os.chmod(a.out, 0o600)
    except OSError:
        pass
    print("\nSigned in. Saved the login to: %s" % os.path.abspath(a.out))
    print("Treat that file like a password. The game deletes it after importing it.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)
