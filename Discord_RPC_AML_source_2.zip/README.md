# Hexed Discord RPC - native AML mod (v2.1)

Native replacement for the `SampDiscordRpc` APK + `Discord_RPC_Bridge.lua`.
Everything now runs inside the Nezuko process (MonetLoader + AML): no second app, no UDP.

```
SA-MP client -> Discord_RPC.lua (menu, game info) -> FFI -> libDiscord_RPC.so (AML mod)
                                                         -> core + Discord Social SDK -> Discord
```

## Build (GitHub)
1. Push this folder to a repo, open **Actions -> Build Discord_RPC AML mod -> Run workflow** (it also runs on push).
2. Download the `Discord_RPC_AML` artifact. It has one folder per ABI (Nezuko is `armeabi-v7a`).
3. Optional: `-DHX_APP_ID=<id>` in the workflow changes the built-in application id (default is the one from the APK).

## Install (armeabi-v7a folder)
```
<your AML mods folder>/libDiscord_RPC.so            <- the AML mod
<your AML mods folder>/Discord_RPC/                 <- support folder, keep next to the .so
        libhxrpc_core.so
        libdiscord_partner_sdk.so
        hx_dex.jar
<MonetLoader scripts folder>/Discord_RPC.lua
```
Delete the old `Discord_RPC_Bridge.lua`, otherwise both scripts will fight over the presence.

## Use
- `/drpc` opens the menu: **Log in with Discord**, **Log out**, enable toggle, live status.
- `/rpcdebug` prints the status in chat, `/rpctoggle` flips presence on/off.
- Logging in uses the SDK's **device-code login** (an APK-only redirect can't exist inside the game).
  In the Discord developer portal the application must be a **Public Client**.
  The login is saved (refresh token, atomic write) in the app's private `files/hxrpc/` folder and renewed automatically.
- Without a login it falls back to the local Discord app, same as the APK's "Start service" mode.

## How the pieces fit
| File | Role |
|---|---|
| `src/stub.cpp` -> `libDiscord_RPC.so` | The AML mod. Copies support files to private storage, builds a `DexClassLoader`, exposes plain C functions to Lua. |
| `java/.../HxBridge.java` -> `hx_dex.jar` | Gives the SDK the game's Activity, then `System.load()`s the core through the same class loader so the SDK's Java and native halves share one copy of the SDK. |
| `src/core.cpp` -> `libhxrpc_core.so` | `rpc.cpp` from the APK minus the UDP socket: SDK client, token storage/refresh, presence push. |
| `lua/Discord_RPC.lua` | Menu + SA-MP data, replaces the bridge script. |

## Not tested on a device yet
This was written without access to an Android toolchain or a device, so the first build/run is the real test. `core.cpp` was
syntax-checked against the real `discordpp.h`; the rest was not compiled. If something fails, `/rpcdebug` shows the stage, and
`adb logcat -s HexedRPC` has the full detail. The most likely trouble spots, in order:
1. `HxBridge.init` fails (no Activity found / class loader problem) - the error text names it.
2. The SDK expects its Java classes from a native thread (`FindClass`) and can't see the dex loader's classes.
3. `GetTokenFromDevice` shows its code/link in a way that isn't visible in-game - if so, say what appears and the UI can be adapted.

## v2.1 - "partner SDK .so not detected" / Log in does nothing
Cause: the mod only looked for `Discord_RPC/` next to the place AML *loaded* `libDiscord_RPC.so` from, which is not always the
folder the files were copied to. It also tried only once per game session, so a failed first try could never recover.
- `Discord_RPC.lua` now reads `/proc/self/maps` to find where AML really loaded the mod, finds your `Discord_RPC` folder
  (script folder, AMLMods, Android/data/<package>/files, ...) and copies it next to the loaded mod **before** the first start.
  This works with the already-built `.so` files, no rebuild needed. The menu shows "Mod loaded from" and "Setup".
- `libDiscord_RPC.so` (needs a rebuild): searches several AML folders, reports the exact path + errno on failure,
  and retries file problems instead of giving up for the whole session.
- `HxBridge.init` loads the SDK by absolute path first, so a linker problem is reported with its real reason
  instead of "library not found".
- Login: `core` reports "Discord login screen closed" if the SDK showed its device screen, and a second press restarts a pending login.

## v2.2 - game crash when pressing "Log in with Discord"
The SDK's own `NativeCalls` (login link, foreground service) needs manifest entries and androidx libraries that the
game does not have, and throws on the main thread, which kills the game. `java/com/discord/socialsdk/NativeCalls.java`
replaces it (the build strips the original from the dex): same methods, never throws, opens the link with a plain
ACTION_VIEW intent. Not tested on a device. If the game still closes, `adb logcat -b crash` has the real reason.

## v2.3 - login that cannot use the SDK's login screen + crash diagnostics (all .so files and hx_dex.jar must be replaced together, the API version changed)
- **Log in with a code** (new, in `/drpc`): 1. *Open login page* opens a normal Discord authorize link (PKCE, built by the SDK),
  2. approve, the browser ends on `http://localhost/?code=...` ("can't connect" page), copy that address,
  3. *Paste & finish* sends it to the SDK (`GetToken`, plain HTTPS, no Android UI at all). Add `http://localhost`
  under OAuth2 > Redirects of the Discord application once.
- **Diagnostics**: `trace.txt` (breadcrumbs + the SDK's own log, written and closed line by line so a crash cannot lose them) and
  `crash.txt` (any uncaught Java exception) in `files/hxrpc/`. *Show crash log / trace* in `/drpc` prints them after the next start.
  If the trace ends at "calling GetTokenFromDevice" with no crash.txt, the crash is native inside the SDK.

## v2.4 - sign in OUTSIDE the game (nothing is opened from inside the game)
Every in-game login (SDK device screen, SDK browser login, "Open login page") makes the game open a screen/browser or run SDK
UI code from inside the game process, and that is what was killing the game. v2.4 moves the login out of the game:

1. **Sign in** with `tools/discord_login.py` on a PC, or on the phone in Termux (`pkg install python`, `python discord_login.py`).
   It prints a Discord link, you press Authorize, the browser ends on a `http://localhost/?code=...` "can't be reached" page,
   you paste that address into the script. It exchanges the code (OAuth2 + PKCE, public client, no secret) and writes
   `Discord_RPC_login.txt` (one line = the refresh token).
   One-time portal setup: application is a **Public Client**, and `http://localhost` is under OAuth2 > Redirects.
2. **Hand it to the game** - either:
   - put `Discord_RPC_login.txt` in the script folder, an AML mods folder, `Android/data/<game>/files` or `Download`;
     it is imported on the next game start (or press *Import login from file* in `/drpc`), then the file is deleted; or
   - copy the token text and press *Import login from clipboard* in `/drpc`.
3. The mod restores it with the SDK's normal `RefreshToken` (plain HTTPS), connects and renews it by itself from then on.

Other changes:
- The in-game login buttons are now under a collapsed **Advanced** header in `/drpc`.
- A rejected/expired saved login no longer falls back into the SDK login screen automatically; it just says "Saved login expired".
- API version 3: `libDiscord_RPC.so`, `libhxrpc_core.so` and `Discord_RPC.lua` must all be replaced together (`hx_dex.jar` is unchanged).

The refresh token is a password for this app's Discord permissions (presence only: `openid sdk.social_layer_presence`).
Do not post it anywhere. *Log out* in `/drpc` erases it from the game; "Deauthorize" in Discord > Settings > Authorized Apps revokes it.

Tested: the helper script (PKCE test vector, link, code parsing, token exchange against a local mock server), the Lua import
logic (with a fake library), and `core.cpp` compiles. NOT tested: a real Discord token exchange (no access from my environment),
`stub.cpp` (only a one-function addition, same pattern as its neighbours) and anything on a device.
