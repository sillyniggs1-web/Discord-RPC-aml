// Hexed Discord RPC - AML mod (libDiscord_RPC.so)  [v3.2: support-folder design + in-game browser login]
// This is the file AML loads. It stays small and has no link dependency on the Discord SDK:
//   1. finds the support folder Discord_RPC/ (libhxrpc_core_v3.so, libdiscord_partner_sdk.so, hx_dex_v2.jar) - next to
//      this .so, or in any AML folder - and copies the files into the app's private dir <filesDir>/hxrpc
//   2. builds a DexClassLoader with the SDK's Java classes + HxBridge
//   3. HxBridge gives the SDK the game's Activity and System.load()s the SDK and the core through that loader
//   4. fetches the core's function table and exposes it to Lua over plain C (FFI)

#include "mod/amlmod.h"
#include <jni.h>
#include <android/log.h>
#include <dirent.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>
#include <vector>
#include "api.h"

#ifndef HX_DEFAULT_APP_ID
#define HX_DEFAULT_APP_ID 0ULL
#endif

#define TAG "HexedRPC"

MYMOD(net.hexedstudio.discordrpc, Hexed Discord RPC, 3.3.0, HEXED Studio)

namespace {

std::mutex g_mu;
bool g_javaFailed = false;   // Java stage failed: a second try in the same process cannot work, needs a game restart
HxApi* g_api = nullptr;
char g_err[512] = "not started";
std::string g_work;          // <filesDir>/hxrpc, also where the saved Discord login and the log live
std::string g_logPath;

jclass g_bridge = nullptr;   // HxBridge (global ref)
jobject g_ctx = nullptr;     // the Activity / Context handed to HxBridge (global ref)
jmethodID g_clipGet = nullptr;
jmethodID g_clipSet = nullptr;

void logLine(const std::string& s) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", s.c_str());
    if (g_logPath.empty()) return;
    if (FILE* f = std::fopen(g_logPath.c_str(), "a")) {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);
        char ts[16];
        std::strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        std::fprintf(f, "%s stub  %s\n", ts, s.c_str());
        std::fclose(f);
    }
}

void setErr(const std::string& s) {
    std::snprintf(g_err, sizeof(g_err), "%s", s.c_str());
    logLine("ERROR: " + s);
}

// Java-stage failure: remember it, a retry would only hit "Could not initialize class"
bool failJava(const std::string& s) {
    g_javaFailed = true;
    setErr(s + " (restart the game after fixing this)");
    return false;
}

// ---------------------------------------------------------------- support files (Discord_RPC/ folder)

std::string modDir() {
    Dl_info info{};
    if (!dladdr(reinterpret_cast<void*>(&modDir), &info) || !info.dli_fname) return ".";
    std::string p = info.dli_fname;
    auto slash = p.find_last_of('/');
    return slash == std::string::npos ? "." : p.substr(0, slash);
}

const char* const kSdk  = "libdiscord_partner_sdk.so";
const char* const kCore = "libhxrpc_core_v3.so";   // _v<HX_API_VERSION>: stale cores from older builds are ignored
const char* const kDex  = "hx_dex_v2.jar";

bool fileOk(const std::string& p) {
    struct stat st{};
    return stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0 && access(p.c_str(), R_OK) == 0;
}

bool dirHasSupport(const std::string& d) {
    return fileOk(d + "/" + kSdk) && fileOk(d + "/" + kCore) && fileOk(d + "/" + kDex);
}

std::string missingIn(const std::string& d) {
    std::string m;
    for (const char* f : { kSdk, kCore, kDex })
        if (!fileOk(d + "/" + f)) m += std::string(m.empty() ? "" : ", ") + f;
    return m;
}

// "" = ok, otherwise what went wrong (with errno)
std::string copyFile(const std::string& from, const std::string& to, mode_t mode) {
    FILE* in = std::fopen(from.c_str(), "rb");
    if (!in) return "cannot read " + from + " (" + std::strerror(errno) + ")";
    std::fseek(in, 0, SEEK_END);
    long size = std::ftell(in);
    std::fseek(in, 0, SEEK_SET);
    struct stat a{}, b{};
    if (stat(to.c_str(), &b) == 0 && b.st_size == size && stat(from.c_str(), &a) == 0 && b.st_mtime >= a.st_mtime) {
        std::fclose(in);
        return "";   // already current
    }
    unlink(to.c_str());   // may be read-only
    FILE* out = std::fopen(to.c_str(), "wb");
    if (!out) { std::string e = std::strerror(errno); std::fclose(in); return "cannot write " + to + " (" + e + ")"; }
    char buf[1 << 15];
    size_t n;
    bool ok = true;
    while ((n = std::fread(buf, 1, sizeof(buf), in)) > 0)
        if (std::fwrite(buf, 1, n, out) != n) { ok = false; break; }
    std::fclose(in);
    if (std::fclose(out) != 0) ok = false;
    if (!ok) return "write failed for " + to + " (" + std::strerror(errno) + ")";
    chmod(to.c_str(), mode);
    return "";
}

// ---- where are the support files? -------------------------------------------------------------
// AML may load this .so from a different place than the folder the user copied it to (some AML
// versions copy mods into private storage first), so "next to the .so" is only the first guess.

std::vector<std::string> baseDirs() {
    std::vector<std::string> b;
    auto add = [&](const std::string& raw) {
        std::string s = raw;
        while (s.size() > 1 && s.back() == '/') s.pop_back();
        if (s.empty()) return;
        for (const auto& x : b) if (x == s) return;
        b.push_back(s);
    };
    auto addc = [&](const char* p) { if (p && *p) add(p); };
    add(modDir());
    addc(aml->GetInternalModsPath());
    addc(aml->GetAndroidDataPath());
    addc(aml->GetAndroidDataRootPath());
    addc(aml->GetConfigPath());
    addc(aml->GetDataPath());
    return b;
}

void scanDirs(const std::string& root, int depth, int& budget, std::vector<std::string>& found) {
    if (depth < 0 || budget <= 0 || found.size() >= 4) return;
    --budget;
    if (dirHasSupport(root + "/Discord_RPC")) found.push_back(root + "/Discord_RPC");
    DIR* d = opendir(root.c_str());
    if (!d) return;
    while (dirent* e = readdir(d)) {
        if (e->d_name[0] == '.') continue;
        if (e->d_type == DT_DIR || e->d_type == DT_UNKNOWN) scanDirs(root + "/" + e->d_name, depth - 1, budget, found);
        if (found.size() >= 4 || budget <= 0) break;
    }
    closedir(d);
}

// returns the folder holding all three files, "" if none; `tried` lists what was checked
std::string findSupportDir(std::string& tried) {
    const auto bases = baseDirs();
    auto check = [&](const std::string& dir) {
        if (dirHasSupport(dir)) return true;
        if (tried.size() < 300) tried += (tried.empty() ? "" : " | ") + dir;
        return false;
    };
    for (const auto& b : bases) {
        if (check(b + "/Discord_RPC")) return b + "/Discord_RPC";
        if (check(b)) return b;
    }
    int budget = 1500;
    std::vector<std::string> found;
    for (const auto& b : bases) {
        scanDirs(b, 3, budget, found);
        if (!found.empty()) break;
    }
    return found.empty() ? std::string() : found.front();
}


// copies the three support files from `src` into `work`; "" = ok, otherwise what went wrong
std::string copySupport(const std::string& src, const std::string& work) {
    bool dexChanged = false;
    for (const char* f : { kSdk, kCore, kDex }) {
        struct stat before{};
        const bool had = stat((work + "/" + f).c_str(), &before) == 0;
        const std::string e = copyFile(src + "/" + f, work + "/" + f, std::strcmp(f, kDex) == 0 ? 0444 : 0755);
        if (!e.empty()) return e;
        struct stat after{};
        if (std::strcmp(f, kDex) == 0 && (!had || (stat((work + "/" + f).c_str(), &after) == 0 && (after.st_mtime != before.st_mtime || after.st_size != before.st_size))))
            dexChanged = true;
    }
    // the DexClassLoader writes optimized code into odex/: stale output from an older dex must go
    if (dexChanged) unlink((work + "/odex/hx_dex_v2.dex").c_str());
    return "";
}

// ---------------------------------------------------------------- JNI helpers

JNIEnv* jenv() {
    JavaVM* vm = aml->GetJavaVM();
    if (!vm) return nullptr;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) return env;
    if (vm->AttachCurrentThread(&env, nullptr) == JNI_OK) return env;
    return nullptr;
}

// description of a pending Java exception, then clear it
std::string takeException(JNIEnv* env) {
    if (!env->ExceptionCheck()) return "";
    jthrowable t = env->ExceptionOccurred();
    env->ExceptionClear();
    std::string out = "Java exception";
    jclass tc = env->FindClass("java/lang/Throwable");
    jmethodID ts = env->GetMethodID(tc, "toString", "()Ljava/lang/String;");
    if (ts && t) {
        jstring js = (jstring)env->CallObjectMethod(t, ts);
        if (js) {
            const char* c = env->GetStringUTFChars(js, nullptr);
            if (c) { out = c; env->ReleaseStringUTFChars(js, c); }
        }
    }
    env->ExceptionClear();
    return out;
}

std::string javaString(JNIEnv* env, jobject obj, const char* method) {
    jclass c = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(c, method, "()Ljava/lang/String;");
    if (!m) { env->ExceptionClear(); return ""; }
    jstring s = (jstring)env->CallObjectMethod(obj, m);
    if (!s) return "";
    const char* c8 = env->GetStringUTFChars(s, nullptr);
    std::string r = c8 ? c8 : "";
    if (c8) env->ReleaseStringUTFChars(s, c8);
    return r;
}

bool bootstrap() {
    JNIEnv* env = jenv();
    if (!env) { setErr("no JNIEnv (AML gave no JavaVM / attach failed)"); return false; }

    // only the app context is requested from AML (works on every AML version); HxBridge finds the Activity by itself
    jobject ctx = aml->GetCurrentContext();
    if (!ctx) { setErr("no app context from AML"); return false; }

    // --- private working dir: <filesDir>/hxrpc
    jclass ctxCls = env->GetObjectClass(ctx);
    jmethodID getFiles = env->GetMethodID(ctxCls, "getFilesDir", "()Ljava/io/File;");
    jobject filesDir = getFiles ? env->CallObjectMethod(ctx, getFiles) : nullptr;
    if (!filesDir) { setErr("getFilesDir failed: " + takeException(env)); return false; }
    const std::string work = javaString(env, filesDir, "getAbsolutePath") + "/hxrpc";
    mkdir(work.c_str(), 0700);
    mkdir((work + "/odex").c_str(), 0700);
    g_work = work;
    g_logPath = work + "/hxrpc.log";
    {   // keep the log small: start a fresh one when it grew past 256 KB
        struct stat st{};
        if (stat(g_logPath.c_str(), &st) == 0 && st.st_size > 256 * 1024) unlink(g_logPath.c_str());
    }
    logLine("bootstrap, work dir " + work);

    // --- find the support files and copy them out of the mods folder (not a Java failure: can be retried)
    {
        std::string tried;
        const std::string src = findSupportDir(tried);
        if (!src.empty()) {
            logLine("support files found in " + src);
            const std::string e = copySupport(src, work);
            if (!e.empty()) { setErr(e); return false; }
        } else if (dirHasSupport(work)) {
            logLine("support folder not found, reusing the files copied earlier in " + work);
        } else {
            const std::string first = modDir() + "/Discord_RPC";
            setErr("Support files not found (" + missingIn(first) + " missing in " + first + "). Mod was loaded from " +
                   modDir() + ". Looked in: " + tried);
            return false;
        }
    }

    // --- DexClassLoader(dexPath, odexDir, libDir, parent = the game's loader)
    jmethodID getLoader = env->GetMethodID(ctxCls, "getClassLoader", "()Ljava/lang/ClassLoader;");
    jobject parent = env->CallObjectMethod(ctx, getLoader);
    jclass dcl = env->FindClass("dalvik/system/DexClassLoader");
    jmethodID dclInit = env->GetMethodID(dcl, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
    jstring jDex = env->NewStringUTF((work + "/" + kDex).c_str());
    jstring jOpt = env->NewStringUTF((work + "/odex").c_str());
    jstring jLib = env->NewStringUTF(work.c_str());
    jobject loader = env->NewObject(dcl, dclInit, jDex, jOpt, jLib, parent);
    if (!loader) return failJava("DexClassLoader: " + takeException(env));

    jmethodID loadClass = env->GetMethodID(dcl, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    jstring jName = env->NewStringUTF("com.hexed.rpc.HxBridge");
    jclass bridge = (jclass)env->CallObjectMethod(loader, loadClass, jName);
    if (!bridge) return failJava("loadClass HxBridge: " + takeException(env));
    bridge = (jclass)env->NewGlobalRef(bridge);

    // --- HxBridge.init(ctx, sdkPath, corePath)
    jmethodID init = env->GetStaticMethodID(bridge, "init",
        "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    if (!init) return failJava("HxBridge.init not found: " + takeException(env));
    jstring jSdk  = env->NewStringUTF((work + "/" + kSdk).c_str());
    jstring jCore = env->NewStringUTF((work + "/" + kCore).c_str());
    jstring res = (jstring)env->CallStaticObjectMethod(bridge, init, ctx, jSdk, jCore);
    if (env->ExceptionCheck()) return failJava("HxBridge.init: " + takeException(env));
    if (res) {
        const char* c = env->GetStringUTFChars(res, nullptr);
        const std::string msg = std::string("HxBridge.init: ") + (c ? c : "?");
        if (c) env->ReleaseStringUTFChars(res, c);
        return failJava(msg);
    }

    // --- HxBridge.apiTable() -> function table inside the core
    jmethodID tbl = env->GetStaticMethodID(bridge, "apiTable", "()J");
    jlong addr = tbl ? env->CallStaticLongMethod(bridge, tbl) : 0;
    if (env->ExceptionCheck()) return failJava("apiTable: " + takeException(env));
    g_api = reinterpret_cast<HxApi*>(static_cast<intptr_t>(addr));
    if (!g_api) return failJava("core returned no API table");
    if (g_api->version != HX_API_VERSION) {
        const int got = g_api->version;
        g_api = nullptr;
        return failJava("core API mismatch (core v" + std::to_string(got) + ", mod expects v" +
                        std::to_string(HX_API_VERSION) + "): an old libhxrpc_core was loaded");
    }

    // --- clipboard helpers (optional: login still works without them, the user then has to type)
    g_bridge = bridge;
    g_ctx = env->NewGlobalRef(ctx);
    g_clipGet = env->GetStaticMethodID(bridge, "clipGet", "(Landroid/content/Context;)Ljava/lang/String;");
    g_clipSet = env->GetStaticMethodID(bridge, "clipSet", "(Landroid/content/Context;Ljava/lang/String;)Z");
    env->ExceptionClear();

    std::snprintf(g_err, sizeof(g_err), "ok");
    logLine("bootstrap ok");
    return true;
}

HxApi* api() {
    std::lock_guard<std::mutex> lock(g_mu);
    return g_api;
}

} // namespace

extern "C" {

#define HX_EXPORT __attribute__((visibility("default")))

// ---- exported for Lua (ffi.load) -------------------------------------------------------------
// returns 1 on success; on failure hx_rpc_error() says why. Safe to call again after a file problem.
// appId: decimal string, "" = built-in default.
HX_EXPORT int hx_rpc_start(const char* appId) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        if (!g_api) {
            if (g_javaFailed) return 0;          // error text stays; needs a game restart
            if (!bootstrap()) return 0;          // file problems are retried on the next call
        }
    }
    unsigned long long id = (appId && *appId) ? std::strtoull(appId, nullptr, 10) : HX_DEFAULT_APP_ID;
    if (id == 0) { setErr("no Discord application id"); return 0; }
    return g_api->start(id, g_work.c_str());
}
HX_EXPORT const char* hx_rpc_error() { return g_err; }
HX_EXPORT const char* hx_rpc_work_dir() { return g_work.c_str(); }
HX_EXPORT void hx_rpc_stop()         { if (auto* a = api()) a->stop(); }
HX_EXPORT void hx_rpc_clear()        { if (auto* a = api()) a->clear(); }
HX_EXPORT void hx_rpc_login()        { if (auto* a = api()) a->login(); }
HX_EXPORT void hx_rpc_login_device() { if (auto* a = api()) a->loginDevice(); }
HX_EXPORT void hx_rpc_logout()       { if (auto* a = api()) a->logout(); }
HX_EXPORT int  hx_rpc_login_url(char* out, int cap) { if (auto* a = api()) return a->loginUrl(out, cap); return 0; }
HX_EXPORT void hx_rpc_login_finish(const char* pasted) { if (auto* a = api()) a->loginFinish(pasted); }
HX_EXPORT void hx_rpc_set_state(const char* nick, int id, const char* server,
                                const char* ip, int port, int players, long long start) {
    if (auto* a = api()) a->setState(nick, id, server, ip, port, players, start);
}
HX_EXPORT void hx_rpc_set_extras(const HxExtras* e) { if (auto* a = api()) a->setExtras(e); }
HX_EXPORT int hx_rpc_status(char* out, int cap) {
    if (auto* a = api()) return a->status(out, cap);
    if (out && cap > 0) std::snprintf(out, static_cast<size_t>(cap), "%s", g_err);
    return 0;
}
HX_EXPORT int hx_rpc_flags() {
    if (auto* a = api()) return a->flags();
    return 0;
}

// text on the clipboard -> out. Returns the length, 0 when empty or not available.
HX_EXPORT int hx_rpc_clipboard_get(char* out, int cap) {
    if (!out || cap <= 0) return 0;
    out[0] = 0;
    if (!g_bridge || !g_clipGet) return 0;
    JNIEnv* env = jenv();
    if (!env) return 0;
    jstring s = (jstring)env->CallStaticObjectMethod(g_bridge, g_clipGet, g_ctx);
    if (env->ExceptionCheck()) { logLine("clipboard read: " + takeException(env)); return 0; }
    if (!s) return 0;
    const char* c = env->GetStringUTFChars(s, nullptr);
    if (c) {
        std::snprintf(out, static_cast<size_t>(cap), "%s", c);
        env->ReleaseStringUTFChars(s, c);
    }
    env->DeleteLocalRef(s);
    return static_cast<int>(std::strlen(out));
}

// copy text to the clipboard. Returns 1 on success.
HX_EXPORT int hx_rpc_clipboard_set(const char* text) {
    if (!g_bridge || !g_clipSet || !text) return 0;
    JNIEnv* env = jenv();
    if (!env) return 0;
    jstring js = env->NewStringUTF(text);
    jboolean ok = env->CallStaticBooleanMethod(g_bridge, g_clipSet, g_ctx, js);
    env->DeleteLocalRef(js);
    if (env->ExceptionCheck()) { logLine("clipboard write: " + takeException(env)); return 0; }
    return ok ? 1 : 0;
}

} // extern "C"

ON_MOD_UNLOAD() {
    if (auto* a = api()) a->stop();
}
