// Function table shared by the stub (libDiscord_RPC.so) and the core (libhxrpc_core.so).
// The stub gets the table's address from HxBridge.apiTable() after the Java side loaded the core.
#pragma once
#define HX_API_VERSION 3
// Presence look, filled from the Lua INI. Every string may use {server} {nick} {id} {ip} {port} {players}.
// flags: bit0 party "(x of y)", bit1 buttons, bit2 elapsed timer, bit3 small image.
struct HxExtras {
    const char* detailsTpl;
    const char* stateTpl;
    const char* largeImage;   // Rich Presence art asset key or https URL ("" = none)
    const char* largeText;
    const char* smallImage;
    const char* smallText;
    const char* btn1Label; const char* btn1Url;
    const char* btn2Label; const char* btn2Url;
    int maxPlayers;
    int flags;
};
struct HxApi {
    int  version;
    int  (*start)(unsigned long long appId, const char* dir);
    void (*stop)();
    void (*setState)(const char* nick, int id, const char* server, const char* ip, int port, int players, long long start);
    void (*clear)();
    void (*login)();                          // restore the saved login, otherwise prepare the browser login link
    void (*loginDevice)();                    // experimental: the SDK's device-code login
    int  (*loginUrl)(char* out, int cap);     // the browser login link once it is ready (0 = not ready yet)
    void (*loginFinish)(const char* pasted);  // the copied browser address (or just the code)
    void (*logout)();
    int  (*status)(char* out, int cap);
    int  (*flags)();   // bit0 ready, bit1 authed, bit2 saved login, bit3 running, bit4 waiting for the pasted address
    void (*setExtras)(const HxExtras* e);     // v3: presence look (templates, images, party, buttons)
};
