// Hexed Discord RPC - core library (libhxrpc_core.so)
// Discord Social SDK + rich presence. Loaded through the dex class loader by HxBridge, so it shares one
// copy of libdiscord_partner_sdk.so (and its JNI state) with the SDK's Java classes.
// Logic comes from the SampDiscordRpc APK (rpc.cpp) and the old AML source (core.cpp). No UDP socket:
// the Lua script pushes the game state straight in through the stub (libDiscord_RPC.so).
//
// Login: the mod cannot add an Activity / redirect to Nezuko's manifest, so the SDK's Authorize() is not used.
//   1. prepare an OAuth2 PKCE link (opened in the browser by the Lua script)
//   2. the user approves; the browser then shows "can't be reached" for http://localhost/callback?code=...
//   3. the user copies that address, the script hands it to loginFinish(), the SDK's GetToken() swaps it for tokens
// The refresh token is stored (atomic write) and renewed automatically, so this is needed only once.

#define DISCORDPP_IMPLEMENTATION // exactly one file
#include "discordpp.h"

#include <jni.h>
#include <android/log.h>
#include <sys/stat.h>

#include <atomic>
#include <cctype>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "api.h"

#define TAG "HexedRPC"

namespace {

// OAuth redirect: register EXACTLY this under OAuth2 > Redirects in the Discord developer portal.
const char* const kRedirect = "http://localhost/callback";
// ask Discord for a user install (counts under "Individual Users"); needs User Install enabled in the portal
const bool kUserInstall = true;

std::atomic<bool> g_run{false};
std::thread g_thread;
std::mutex g_mu;              // guards g_status, g_state, g_loginUrl, g_verifier, g_pasted
std::string g_status = "Stopped";
std::string g_logPath;

std::atomic<bool> g_authed{false};       // a token was accepted and Connect() was called
std::atomic<bool> g_ready{false};        // SDK status is Ready
std::atomic<bool> g_loginReq{false};     // user pressed Log in
std::atomic<bool> g_beginReq{false};     // prepare the browser login link
std::atomic<bool> g_finishReq{false};    // the pasted address is in g_pasted
std::atomic<bool> g_deviceReq{false};    // experimental device-code login
std::atomic<bool> g_waitingCode{false};  // link prepared, waiting for the pasted address
std::atomic<bool> g_repush{false};
std::atomic<bool> g_needRefresh{false};
std::atomic<bool> g_refreshing{false};   // refresh tokens rotate: never run two requests at once
std::atomic<bool> g_logoutReq{false};
std::atomic<bool> g_deviceLoginPending{false};
std::string g_tokenPath;
std::string g_loginUrl;
std::string g_verifier;
std::string g_pasted;

struct State {
    bool active = false;
    std::string nick, server, ip;
    int port = 7777;
    int players = 0;
    int id = -1;
    long long start = 0;
};
State g_state;
struct Look {
    std::string details = "{server}", state = "{nick} \xE2\x80\xA2 {ip}:{port}";
    std::string largeImage, largeText = "{server}", smallImage, smallText = "{nick} (ID {id})";
    std::string b1l, b1u, b2l, b2u;
    int maxPlayers = 1000;
    int flags = 1 | 4;
};
Look g_look;                       // guarded by g_mu
std::atomic<int> g_lookVer{0};
std::atomic<unsigned long long> g_appId{0};
std::atomic<long long> g_lastSetMs{0};   // steady-clock ms of the last state pushed by Lua

long long nowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

void logLine(const std::string& s) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", s.c_str());
    if (g_logPath.empty()) return;
    if (FILE* f = std::fopen(g_logPath.c_str(), "a")) {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);
        char ts[16];
        std::strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        std::fprintf(f, "%s core  %s\n", ts, s.c_str());
        std::fclose(f);
    }
}

void setStatus(const std::string& s) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_status = s;
    }
    logLine(s);
}

std::string clip(const std::string& s, size_t max) {
    if (s.size() <= max) return s;
    size_t n = max;
    while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;
    return s.substr(0, n);
}

// ---------------------------------------------------------------- saved login (refresh token)

std::string readRefresh() {
    std::string out;
    if (FILE* f = std::fopen(g_tokenPath.c_str(), "r")) {
        char b[1024];
        while (std::fgets(b, sizeof(b), f)) out += b;
        std::fclose(f);
    }
    while (!out.empty() && (out.back() == '\n' || out.back() == '\r' || out.back() == ' ')) out.pop_back();
    return out;
}

void writeRefresh(const std::string& token) {
    // temp file + rename: a kill in the middle must never lose the (rotated) token
    const std::string tmp = g_tokenPath + ".tmp";
    if (FILE* f = std::fopen(tmp.c_str(), "w")) {
        const bool ok = std::fputs(token.c_str(), f) >= 0;
        std::fclose(f);
        chmod(tmp.c_str(), 0600);
        if (ok) std::rename(tmp.c_str(), g_tokenPath.c_str());
    }
}

void eraseRefresh() {
    std::remove(g_tokenPath.c_str());
    std::remove((g_tokenPath + ".tmp").c_str());
}

// ---------------------------------------------------------------- token -> connection

void connectWith(const std::shared_ptr<discordpp::Client>& client,
                 discordpp::AuthorizationTokenType type, const std::string& access) {
    client->UpdateToken(type, access, [client](discordpp::ClientResult r) {
        if (!r.Successful()) {
            setStatus("Token update failed, retrying: " + std::string(r.Error()));
            g_needRefresh = true;
            return;
        }
        g_authed = true;
        // already connected (token just renewed in the background): nothing more to do
        if (client->GetStatus() == discordpp::Client::Status::Disconnected) {
            setStatus("Connecting to Discord...");
            client->Connect();
        }
    });
}

// swap the saved refresh token for a fresh access token, then connect. Used on start, when the token is
// about to expire and after a dropped connection, so the user never has to log in again.
void tryRefresh(const std::shared_ptr<discordpp::Client>& client, uint64_t appId, bool loginIfInvalid) {
    const std::string rt = readRefresh();
    if (rt.empty()) return;
    if (g_refreshing.exchange(true)) return;
    setStatus("Restoring saved Discord login...");
    client->RefreshToken(appId, rt, [client, rt, loginIfInvalid](discordpp::ClientResult r, std::string access,
                                             std::string refresh, discordpp::AuthorizationTokenType type,
                                             int32_t, std::string) {
        g_refreshing = false;
        if (!r.Successful()) {
            const int http = static_cast<int>(r.Status());
            if (http == 400 || http == 401 || http == 403) {
                // Discord rejected the refresh token (revoked or expired): the only case that needs a new login
                if (readRefresh() == rt) eraseRefresh();
                g_authed = false;
                if (loginIfInvalid) {
                    setStatus("Saved login expired - preparing a new login link...");
                    g_beginReq = true;
                } else {
                    setStatus("Saved login expired - press Log in with Discord");
                }
            } else {
                setStatus("Discord unreachable, retrying: " + std::string(r.Error()));
                g_needRefresh = true;   // network problem: keep the saved login and try again
            }
            return;
        }
        if (!refresh.empty()) writeRefresh(refresh);
        connectWith(client, type, access);
    });
}

// ---------------------------------------------------------------- browser (PKCE) login

std::string urlEncode(const std::string& s) {
    static const char* const hex = "0123456789ABCDEF";
    std::string o;
    for (unsigned char c : s) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            o += static_cast<char>(c);
        } else {
            o += '%';
            o += hex[c >> 4];
            o += hex[c & 15];
        }
    }
    return o;
}

// value of ?key=... / &key=... in a pasted address
std::string queryParam(const std::string& in, const std::string& key) {
    const std::string needle = key + "=";
    size_t p = 0;
    while ((p = in.find(needle, p)) != std::string::npos) {
        const bool atStart = p == 0 || in[p - 1] == '?' || in[p - 1] == '&' || in[p - 1] == '#' ||
                             std::isspace(static_cast<unsigned char>(in[p - 1]));
        if (atStart) {
            const size_t b = p + needle.size();
            size_t e = b;
            while (e < in.size() && in[e] != '&' && in[e] != '#' && !std::isspace(static_cast<unsigned char>(in[e]))) ++e;
            return in.substr(b, e - b);
        }
        p += needle.size();
    }
    return "";
}

// accepts the whole copied address, or just the code
bool extractCode(const std::string& pasted, std::string& code, std::string& err) {
    std::string in = pasted;
    while (!in.empty() && std::isspace(static_cast<unsigned char>(in.back()))) in.pop_back();
    size_t b = 0;
    while (b < in.size() && std::isspace(static_cast<unsigned char>(in[b]))) ++b;
    in = in.substr(b);
    if (in.empty()) { err = "Clipboard is empty: copy the address of the browser page first"; return false; }

    const std::string denied = queryParam(in, "error");
    if (!denied.empty()) { err = "Discord returned: " + denied + " (log in again)"; return false; }

    code = queryParam(in, "code");
    if (code.empty() && in.find_first_of("=/:?&") == std::string::npos && in.size() >= 10) code = in;   // bare code
    if (code.empty()) {
        err = "No login code found in the copied text. Copy the whole address of the page that opened after approving";
        return false;
    }
    return true;
}

void beginLogin(const std::shared_ptr<discordpp::Client>& client, uint64_t appId) {
    discordpp::AuthorizationCodeVerifier verifier = client->CreateAuthorizationCodeVerifier();
    const std::string challenge = verifier.Challenge().Challenge();
    std::string url = "https://discord.com/oauth2/authorize?client_id=" + std::to_string(appId) +
                      "&response_type=code&scope=" + urlEncode(discordpp::Client::GetDefaultPresenceScopes()) +
                      "&code_challenge=" + urlEncode(challenge) +
                      "&code_challenge_method=S256&redirect_uri=" + urlEncode(kRedirect);
    if (kUserInstall) url += "&integration_type=1";
    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_verifier = verifier.Verifier();
        g_loginUrl = url;
        g_pasted.clear();
    }
    g_waitingCode = true;
    setStatus("Login link ready. Approve in the browser, copy the address of the page that opens, then press Finish login");
}

void finishLogin(const std::shared_ptr<discordpp::Client>& client, uint64_t appId) {
    std::string pasted, verifier;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        pasted = g_pasted;
        verifier = g_verifier;
    }
    if (verifier.empty()) { setStatus("Press Log in with Discord first to get a login link"); return; }
    std::string code, err;
    if (!extractCode(pasted, code, err)) { setStatus(err); return; }   // the link stays valid: copy again and retry

    setStatus("Exchanging the Discord login code...");
    client->GetToken(appId, code, verifier, kRedirect, [client](discordpp::ClientResult r, std::string access,
                                                             std::string refresh,
                                                             discordpp::AuthorizationTokenType type,
                                                             int32_t, std::string) {
        g_waitingCode = false;
        {
            std::lock_guard<std::mutex> lock(g_mu);
            g_verifier.clear();   // a code can be used once
            g_loginUrl.clear();
        }
        if (!r.Successful()) {
            setStatus("Token exchange failed: " + std::string(r.Error()) + " (press Log in with Discord to try again)");
            return;
        }
        if (!refresh.empty()) writeRefresh(refresh);
        connectWith(client, type, access);
    });
}

// Experimental: the SDK's device-code login (opens its own Discord / browser screen through the Java side).
void startDeviceLogin(const std::shared_ptr<discordpp::Client>& client, uint64_t appId) {
    discordpp::DeviceAuthorizationArgs args;
    args.SetClientId(appId);
    args.SetScopes(discordpp::Client::GetDefaultPresenceScopes());
    if (g_deviceLoginPending.exchange(true)) client->AbortGetTokenFromDevice();   // pressed twice: restart cleanly
    setStatus("Starting Discord device login... a Discord / browser screen should open");
    client->GetTokenFromDevice(std::move(args), [client](discordpp::ClientResult r, std::string access,
                                                        std::string refresh,
                                                        discordpp::AuthorizationTokenType type,
                                                        int32_t, std::string) {
        g_deviceLoginPending = false;
        if (!r.Successful()) {
            setStatus("Device login failed: " + std::string(r.Error()));
            return;
        }
        if (!refresh.empty()) writeRefresh(refresh);
        connectWith(client, type, access);
    });
}

// ---------------------------------------------------------------- presence

std::string expand(const std::string& tpl, const State& s) {
    std::string out;
    for (size_t i = 0; i < tpl.size();) {
        if (tpl[i] == '{') {
            const size_t e = tpl.find('}', i);
            if (e != std::string::npos) {
                const std::string k = tpl.substr(i + 1, e - i - 1);
                const char* v = nullptr;
                std::string tmp;
                if (k == "server") tmp = s.server.empty() ? std::string("SA-MP server") : s.server;
                else if (k == "nick") tmp = s.nick.empty() ? std::string("player") : s.nick;
                else if (k == "ip") tmp = s.ip;
                else if (k == "port") tmp = std::to_string(s.port);
                else if (k == "players") tmp = std::to_string(s.players);
                else if (k == "id") tmp = std::to_string(s.id);
                else v = "";
                if (v == nullptr) { out += tmp; i = e + 1; continue; }
            }
        }
        out += tpl[i++];
    }
    return out;
}

void push(const std::shared_ptr<discordpp::Client>& client, const State& s) {
    if (!s.active) {
        client->ClearRichPresence();
        setStatus("Presence cleared (not in a server)");
        return;
    }
    Look L;
    {
        std::lock_guard<std::mutex> lock(g_mu);
        L = g_look;
    }

    discordpp::Activity a;
    a.SetType(discordpp::ActivityTypes::Playing);
    a.SetName("San Andreas Multiplayer");
    // the registered game: this is what makes Discord show the game icon in the voice channel member list
    a.SetApplicationId(g_appId.load());
    a.SetStatusDisplayType(discordpp::StatusDisplayTypes::Name);
    a.SetSupportedPlatforms(static_cast<discordpp::ActivityGamePlatforms>(
        static_cast<int>(discordpp::ActivityGamePlatforms::Desktop) |
        static_cast<int>(discordpp::ActivityGamePlatforms::Android) |
        static_cast<int>(discordpp::ActivityGamePlatforms::IOS)));
    a.SetDetails(clip(expand(L.details, s), 120));
    a.SetState(clip(expand(L.state, s), 120));

    if (!L.largeImage.empty() || ((L.flags & 8) && !L.smallImage.empty())) {
        discordpp::ActivityAssets as;
        if (!L.largeImage.empty()) {
            as.SetLargeImage(L.largeImage);
            if (!L.largeText.empty()) as.SetLargeText(clip(expand(L.largeText, s), 120));
        }
        if ((L.flags & 8) && !L.smallImage.empty()) {
            as.SetSmallImage(L.smallImage);
            if (!L.smallText.empty()) as.SetSmallText(clip(expand(L.smallText, s), 120));
        }
        a.SetAssets(as);
    }
    if ((L.flags & 4) && s.start > 0) {
        discordpp::ActivityTimestamps ts;
        ts.SetStart(static_cast<uint64_t>(s.start));
        a.SetTimestamps(ts);
    }
    if ((L.flags & 1) && s.players > 0) {
        discordpp::ActivityParty party;
        party.SetId(s.ip + ":" + std::to_string(s.port));
        party.SetCurrentSize(s.players);
        party.SetMaxSize(L.maxPlayers > s.players ? L.maxPlayers : s.players);
        a.SetParty(party);
    }
    if (L.flags & 2) {
        auto addBtn = [&](const std::string& label, const std::string& url) {
            if (label.empty() || url.compare(0, 4, "http") != 0) return;
            discordpp::ActivityButton b;
            b.SetLabel(clip(label, 32));
            b.SetUrl(url);
            a.AddButton(b);
        };
        addBtn(L.b1l, L.b1u);
        addBtn(L.b2l, L.b2u);
    }
    client->UpdateRichPresence(a, [](discordpp::ClientResult r) {
        if (r.Successful()) setStatus("Presence active");
        else setStatus("Presence failed: " + std::string(r.Error()));
    });
}

// ---------------------------------------------------------------- worker thread

void worker(uint64_t appId) {
    using clock = std::chrono::steady_clock;
    using std::chrono::seconds;

    auto client = std::make_shared<discordpp::Client>();
    client->AddLogCallback([](auto message, auto) { logLine("[sdk] " + std::string(message)); },
                           discordpp::LoggingSeverity::Info);

    // raw pointer on purpose: these callbacks live as long as the client, a shared_ptr would be a cycle
    discordpp::Client* raw = client.get();
    client->SetStatusChangedCallback([raw](discordpp::Client::Status status, discordpp::Client::Error error, int32_t) {
        if (status == discordpp::Client::Status::Ready) {
            g_ready = true;
            g_repush = true;
            std::string name = "Discord";
            if (auto u = raw->GetCurrentUserV2()) name = u->DisplayName();
            setStatus("Logged in as " + name + " (login saved)");
        } else {
            g_ready = false;
            if (error != discordpp::Client::Error::None)
                setStatus("Discord connection error: " + discordpp::Client::ErrorToString(error));
            else
                setStatus("Discord: " + discordpp::Client::StatusToString(status));
            // fully disconnected while we should be logged in: reconnect through the saved login
            if (status == discordpp::Client::Status::Disconnected && g_authed && g_run) g_needRefresh = true;
        }
    });
    client->SetTokenExpirationCallback([]() { g_needRefresh = true; });
    client->SetAuthorizeDeviceScreenClosedCallback([]() { setStatus("Discord login screen closed"); });

    client->SetApplicationId(appId);
    tryRefresh(client, appId, false);
    if (readRefresh().empty()) setStatus("Ready. Not logged in (local Discord app presence)");

    std::string lastKey;
    auto lastPush = clock::time_point{};
    auto nextRefresh = clock::time_point{};

    while (g_run) {
        if (g_logoutReq.exchange(false)) {
            g_authed = false; g_ready = false; g_needRefresh = false; g_waitingCode = false;
            {
                std::lock_guard<std::mutex> lock(g_mu);
                g_verifier.clear();
                g_loginUrl.clear();
            }
            eraseRefresh();
            client->Disconnect();
            setStatus("Logged out. Log in again to use your account");
        }
        if (g_loginReq.exchange(false)) {
            if (g_ready) setStatus("Already logged in (saved). Use Log out to switch account");
            else if (!readRefresh().empty()) tryRefresh(client, appId, true);   // reuse the saved login
            else g_beginReq = true;                                              // first time only
        }
        if (g_beginReq.exchange(false)) beginLogin(client, appId);
        if (g_finishReq.exchange(false)) finishLogin(client, appId);
        if (g_deviceReq.exchange(false)) startDeviceLogin(client, appId);
        if (g_needRefresh && clock::now() >= nextRefresh) {
            g_needRefresh = false;
            nextRefresh = clock::now() + seconds(15);   // backoff between reconnect attempts
            tryRefresh(client, appId, false);
        }

        State cur;
        {
            std::lock_guard<std::mutex> lock(g_mu);
            // the Lua side refreshes the state about every second; 10 s of silence means "left the server"
            if (g_state.active && nowMs() - g_lastSetMs.load() > 10000) g_state = State{};
            cur = g_state;
        }
        const auto now = clock::now();

        std::string key = cur.active
            ? cur.server + "|" + cur.ip + ":" + std::to_string(cur.port) + "|" + cur.nick + "|" + std::to_string(cur.start) +
              "|" + std::to_string(cur.players) + "|" + std::to_string(g_lookVer.load())
            : std::string();
        if (g_repush.exchange(false)) lastKey = "\x01" "force";
        const bool canPush = !g_authed || g_ready;
        if (canPush && (key != lastKey || (cur.active && now - lastPush > seconds(30)))) {
            push(client, cur);
            lastKey = key;
            lastPush = now;
        }
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    client->ClearRichPresence();
    for (int i = 0; i < 5; ++i) {
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

} // namespace

// ---------------------------------------------------------------- function table (HxApi)

static int c_start(unsigned long long appId, const char* dir) {
    if (g_run.exchange(true)) return 1;
    const std::string d = dir ? dir : ".";
    g_tokenPath = d + "/discord_login.txt";
    g_logPath = d + "/hxrpc.log";
    g_authed = false; g_ready = false; g_needRefresh = false; g_refreshing = false; g_logoutReq = false;
    g_waitingCode = false; g_loginReq = false; g_beginReq = false; g_finishReq = false; g_deviceReq = false;
    if (g_thread.joinable()) g_thread.join();
    g_appId = appId;
    logLine("core start, app id " + std::to_string(appId));
    g_thread = std::thread(worker, static_cast<uint64_t>(appId));
    return 1;
}

static void c_stop() {
    g_run = false;
    if (g_thread.joinable()) g_thread.join();
    setStatus("Stopped");
}

static void c_set_state(const char* nick, int id, const char* server, const char* ip, int port, int players, long long start) {
    std::lock_guard<std::mutex> lock(g_mu);
    g_state.active = true;
    g_state.nick = nick ? nick : "";
    g_state.server = server ? server : "";
    g_state.ip = ip ? ip : "";
    g_state.port = port;
    g_state.players = players;
    g_state.id = id;
    g_state.start = start;
    g_lastSetMs = nowMs();
}

static void c_clear() {
    std::lock_guard<std::mutex> lock(g_mu);
    g_state = State{};
}

static void c_login() { g_loginReq = true; }
static void c_login_device() { g_deviceReq = true; }

static int c_login_url(char* out, int cap) {
    if (!out || cap <= 0) return 0;
    std::lock_guard<std::mutex> lock(g_mu);
    std::snprintf(out, static_cast<size_t>(cap), "%s", g_loginUrl.c_str());
    return static_cast<int>(std::strlen(out));
}

static void c_login_finish(const char* pasted) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_pasted = pasted ? pasted : "";
    }
    g_finishReq = true;
}

static void c_logout() {
    if (g_run) g_logoutReq = true;
    else eraseRefresh();
}

static int c_status(char* out, int cap) {
    if (!out || cap <= 0) return 0;
    std::lock_guard<std::mutex> lock(g_mu);
    std::snprintf(out, static_cast<size_t>(cap), "%s", g_status.c_str());
    return static_cast<int>(std::strlen(out));
}

static int c_flags() {
    int f = 0;
    if (g_ready) f |= 1;
    if (g_authed) f |= 2;
    if (!g_tokenPath.empty() && !readRefresh().empty()) f |= 4;
    if (g_run) f |= 8;
    if (g_waitingCode) f |= 16;
    return f;
}

static void c_set_extras(const HxExtras* e) {
    if (!e) return;
    auto S = [](const char* p) { return std::string(p ? p : ""); };
    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_look.details = S(e->detailsTpl);
        g_look.state = S(e->stateTpl);
        g_look.largeImage = S(e->largeImage);
        g_look.largeText = S(e->largeText);
        g_look.smallImage = S(e->smallImage);
        g_look.smallText = S(e->smallText);
        g_look.b1l = S(e->btn1Label); g_look.b1u = S(e->btn1Url);
        g_look.b2l = S(e->btn2Label); g_look.b2u = S(e->btn2Url);
        g_look.maxPlayers = e->maxPlayers;
        g_look.flags = e->flags;
    }
    ++g_lookVer;   // changes the presence key: the worker pushes again at once
}

static HxApi g_api = { HX_API_VERSION, c_start, c_stop, c_set_state, c_clear, c_login, c_login_device,
                       c_login_url, c_login_finish, c_logout, c_status, c_flags, c_set_extras };

// Reached through HxBridge.apiTable() once the Java side has System.load()ed this library.
extern "C" JNIEXPORT jlong JNICALL Java_com_hexed_rpc_HxBridge_apiTable(JNIEnv*, jclass) {
    return static_cast<jlong>(reinterpret_cast<intptr_t>(&g_api));
}
