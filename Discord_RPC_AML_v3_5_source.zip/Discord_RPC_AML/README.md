# Hexed Discord RPC - native AML mod (v3.5)

v3.3 = the old support-folder loading (small stub, known to load in AML) + the v3 in-game browser login.
It only asks AML for the app context (no `GetCurrentActivity`).

Replaces the `SampDiscordRpc` APK + `Discord_RPC_Bridge.lua`. Everything runs inside the Nezuko process
(MonetLoader + AML): no second app, no UDP, no foreground service.

```
SA-MP client -> Discord_RPC.lua (menu, game info) -> FFI -> libDiscord_RPC.so (AML mod)
                                                           -> core + Discord Social SDK -> Discord servers -> any device
```

## Install (v3.3: support folder + 2 files)
Nezuko is 32-bit, use the **armeabi-v7a** folder of the build.
```
<AML mods folder>/libDiscord_RPC.so
<AML mods folder>/Discord_RPC/                 <- keep this folder next to the .so
        libhxrpc_core_v3.so
        libdiscord_partner_sdk.so
        hx_dex_v2.jar
<MonetLoader scripts folder>/Discord_RPC.lua
```
Delete the old `Discord_RPC_Bridge.lua`. On first start the mod finds the `Discord_RPC/` folder (next to the .so or in any AML
folder) and copies the three files into the game's private folder `files/hxrpc/`.

## Build (GitHub)
Push the folder to a repo, run **Actions -> Build Discord_RPC AML mod** (also runs on push), download the `Discord_RPC_AML`
artifact. The workflow builds the dex first (javac + d8), then the native libs for both ABIs; the dex, SDK and core go into the `Discord_RPC/` support folder of the artifact. `-DHX_APP_ID=<id>` changes the built-in application id.

## Discord developer portal (once)
Application -> **OAuth2 -> Redirects**: add exactly `http://localhost/callback`. Turn **Public Client** on.
The login asks for a **user install** (counts under "Individual Users"), so enable **User Install** under *Installation*.
(To skip that, set `kUserInstall = false` in `src/core.cpp`.)

## Menu (v3.4)
`/drpc` opens the redesigned HEXED menu. Fonts and images are embedded in `Discord_RPC.lua` and unpacked on first start into
`<monetloader>/HEXED/DiscordRPC/` (nothing to copy by hand). Tap the Discord badge in the header, or type `/drpc` again, to close it.

## "core API mismatch"
An old `Discord_RPC/` folder (v2.x, API v1) was found somewhere and its old core was loaded. v3.3 names its files
`libhxrpc_core_v3.so` / `hx_dex_v2.jar`, so old folders are ignored. Just install the new `Discord_RPC/` folder and restart the game.

## Use
`/drpc` opens the menu. First login (once; the login is then saved and renewed automatically):
1. **Log in with Discord** - the browser opens (the link is also copied to the clipboard if it doesn't).
2. Approve. The page that opens afterwards says it can't be reached - that is expected. **Copy its address** from the browser.
3. Back in the game press **Finish login**. The status line turns green: "Logged in as ...".

Why not the normal login screen: that needs an Activity and a redirect entry in the app manifest, and a mod cannot add
either to Nezuko. The "device-code login" button (Diagnostics) tries the SDK's own flow instead - experimental.

Other: `/rpcdebug` prints the status in chat, `/rpctoggle` flips presence on/off. **Diagnostics -> Copy diagnostics** puts
the status and the log tail on the clipboard for a bug report. The full log is `files/hxrpc/hxrpc.log` (logcat tag `HexedRPC`).
Without a login it falls back to the local Discord app, like the APK's "Start service" mode.

## What this version took from the old AML source, and what it changed
| | |
|---|---|
| Kept | AML headers, `HxBridge` idea (load the SDK through a dex class loader, give it the Activity), stub + core split with a function table, `AND_OpenLink` for opening links, token handling (atomic refresh-token file, rotation guard, reconnect backoff) |
| Changed | **one file to install** (payload embedded, unpacked on first run) instead of a support folder that had to be found; real Activity from `aml->GetCurrentActivity()` (reflection is only the fallback); **browser login with the clipboard** as the main login, device-code login demoted to experimental; log file + "Copy diagnostics"; Lua menu in the HEXED colors, style pushed only around its own window; C++17 (AML headers) |
| Dropped | the `/proc/self/maps` support-folder hunting and file copying in Lua |

## Status: written without a toolchain or a device
Checked here: `core.cpp` compiles against the real `discordpp.h`; `stub.cpp` has no errors against the AML headers (with stub JNI);
the embedded-payload assembler template and the unpack logic were run on the host (sizes, checksum, idempotent, repair, error text);
Lua block structure and the FFI declarations match the stub's exports.
NOT checked: the CMake/NDK build, the Java compile and d8 step, Lua execution, and everything on a phone.
Most likely trouble spots, in order: `HxBridge.init` (Activity / class loader - the error text says which), the SDK's JNI
class lookup from native threads, a read-only/exec restriction on `files/hxrpc/`, the login redirect settings above.

## v3.5: full "San Andreas Multiplayer" game presence
The activity is now a proper registered game activity: type Playing, your application id attached, supported platforms
(Android / iOS / Desktop), large + small image, party size, timer, buttons. Discord itself shows the game icon next to you
in a voice channel member list while this presence is active - nothing needs to detect the voice channel.
Settings live in `Hexed DiscordRpc.ini` under `[presence]` (created on first start). Type `/rpcreload` in chat to apply edits.
Placeholders in every text: `{server} {nick} {id} {ip} {port} {players}`.

For the **icon in the voice list** and the images, set these once in the Discord Developer Portal (application 1566671569479147600):
1. General Information -> **App Icon**: upload the GTA SA / SA-MP icon (this is the icon shown in the voice list).
2. Rich Presence -> **Art Assets**: upload an image with the key `samp_logo` (or put any https image link in `largeimage`).
3. Rich Presence needs Discord to see a Playing activity from this app; log in once with the browser login (menu `/drpc`).

Needs `libhxrpc_core_v3.so` (new name): replace the whole `Discord_RPC/` folder, the .so and the Lua script together.
