// Function table shared by the stub (libDiscord_RPC.so) and the core (libhxrpc_core.so).
// The stub gets the table's address from HxBridge.apiTable() after the Java side loaded the core.
#pragma once
#define HX_API_VERSION 2
struct HxApi {
    int  version;
    int  (*start)(unsigned long long appId, const char* dir);
    void (*stop)();
    void (*setState)(const char* nick, int id, const char* server, const char* ip, int port, int players, long long start);
    void (*clear)();
    void (*login)();                          // restore the saved login, otherwise prepare the browser login link
    void (*loginDevice)();                    // experimental: the SDK's device-code login
    int  (*loginUrl)(char* out, int cap);     // the browser login link once it is ready (0 = not ready yet)
    void (*loginFinish)(const char* pasted);  // the copied browser address (or just the code)
    void (*logout)();
    int  (*status)(char* out, int cap);
    int  (*flags)();   // bit0 ready, bit1 authed, bit2 saved login, bit3 running, bit4 waiting for the pasted address
};
