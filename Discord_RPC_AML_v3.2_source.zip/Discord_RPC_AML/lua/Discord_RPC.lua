script_name("Hexed Discord RPC")
script_author("HEXED Studio")
script_version("3.2")

-- Lua side of the Discord_RPC AML mod: reads the SA-MP info and hands it to libDiscord_RPC.so over FFI.
-- (replaces Discord_RPC_Bridge.lua + the SampDiscordRpc companion app: no UDP, no second APK)
-- Install: libDiscord_RPC.so into the AML mods folder, this script into the MonetLoader scripts folder. Nothing else.

if script_properties then pcall(script_properties, "work-in-pause") end

require "lib.moonloader"
local ffi      = require("ffi")
local imgui    = require("mimgui")
local inicfg   = require("inicfg")
local encoding = require("encoding")
encoding.default = "CP1251"
local u8 = encoding.UTF8

local INI = "Hexed DiscordRpc.ini"
local cfg = inicfg.load({ main = { enabled = true, appid = "", interval = 1000, grace = 10 } }, INI)
inicfg.save(cfg, INI)

pcall(ffi.cdef, [[
    int         hx_rpc_start(const char* appId);
    const char* hx_rpc_error(void);
    const char* hx_rpc_work_dir(void);
    void        hx_rpc_stop(void);
    void        hx_rpc_clear(void);
    void        hx_rpc_login(void);
    void        hx_rpc_login_device(void);
    int         hx_rpc_login_url(char* out, int cap);
    void        hx_rpc_login_finish(const char* pasted);
    void        hx_rpc_logout(void);
    void        hx_rpc_set_state(const char* nick, int id, const char* server, const char* ip,
                                 int port, int players, long long start);
    int         hx_rpc_status(char* out, int cap);
    int         hx_rpc_flags(void);
    int         hx_rpc_clipboard_get(char* out, int cap);
    int         hx_rpc_clipboard_set(const char* text);
]])

-- opening links: the game's own AND_OpenLink (no Java needed)
pcall(ffi.cdef, "void _Z12AND_OpenLinkPKc(const char* link);")
local okGta, gta = pcall(ffi.load, "GTASA")
local DISCORD_URL = "https://discord.gg/MmqnsXg2QC"

local S = {
    lib = nil, started = false, startAt = 0, key = "", myId = nil,
    lastData = nil, lostAt = 0, win = imgui.new.bool(false),
    buf = ffi.new("char[512]"), urlbuf = ffi.new("char[2048]"), clip = ffi.new("char[4096]"),
    err = "", note = "", nextStart = 0,
    wantUrl = false, wantUntil = 0, url = "",
    logText = "", logAt = 0,
}

-- flag bits from the core
local F_READY, F_AUTHED, F_SAVED, F_RUNNING, F_WAITING = 1, 2, 4, 8, 16
local function has(f, bitv) return bit.band(f, bitv) ~= 0 end

local function say(msg) sampAddChatMessage(msg, -1) end
local function toU8(s) local ok, r = pcall(u8, s); return (ok and r) or s end
local function clean(s) return (tostring(s or ""):gsub("[\t\r\n]", " ")) end

local function openLink(link)
    if okGta and gta then
        local ok = pcall(function() gta._Z12AND_OpenLinkPKc(link) end)
        return ok
    end
    return false
end

-- ---------------------------------------------------------------- library

-- Finds the mod in the process map. AML dlopen()s it from its own folder, so we look for the real path.
-- Matches libDiscord_RPC.so, Discord_RPC.so, or a renamed copy (anything with "discord" + "rpc" in the file name).
local function loadedLibPath()
    local f = io.open("/proc/self/maps", "r")
    if not f then return nil end
    local found
    for line in f:lines() do
        local p = line:match("(/%S*%.so)%s*$")
        if p then
            local name = p:match("([^/]+)$"):lower()
            if name:find("discord", 1, true) and name:find("rpc", 1, true) and not name:find("partner_sdk", 1, true)
               and not name:find("hxrpc_core", 1, true) then
                found = p; break
            end
        end
    end
    f:close()
    return found
end

local function hasApi(l)
    local ok, fn = pcall(function() return l.hx_rpc_start end)
    return ok and fn ~= nil
end

local S_loadLog = ""
local function loadLib()
    local tried = {}
    local function try(what)
        local ok, l = pcall(ffi.load, what)
        if ok and l and hasApi(l) then return l end
        tried[#tried + 1] = what .. " -> " .. (ok and "loaded but hx_rpc_start missing" or tostring(l):sub(1, 90))
        return nil
    end
    -- 1) the exact file AML loaded (most reliable)
    local path = loadedLibPath()
    if path then
        local l = try(path)
        if l then S_loadLog = "loaded: " .. path; return l end
    else
        tried[#tried + 1] = "/proc/self/maps: no Discord_RPC .so mapped (AML did not load the mod)"
    end
    -- 2) by name (the linker matches already-loaded libraries by soname)
    for _, name in ipairs({ "libDiscord_RPC.so", "Discord_RPC", "libDiscord_RPC" }) do
        local l = try(name)
        if l then S_loadLog = "loaded by name: " .. name; return l end
    end
    -- 3) exported globally
    if hasApi(ffi.C) then S_loadLog = "loaded: global symbols"; return ffi.C end
    S_loadLog = table.concat(tried, "\n")
    return nil
end

local function status()
    if not S.lib then return "libDiscord_RPC.so not loaded (is the AML mod installed?)" end
    S.lib.hx_rpc_status(S.buf, 512)
    return ffi.string(S.buf)
end

local function flags() return S.lib and S.lib.hx_rpc_flags() or 0 end

local function start(force)
    if S.started then return true end
    if not force and os.clock() < S.nextStart then return false end
    S.nextStart = os.clock() + 15      -- a failed start is retried every 15 s, or at once from the menu
    if not S.lib then S.lib = loadLib() end
    if not S.lib then S.err = "libDiscord_RPC.so not loaded: " .. (loadedLibPath() and "found in the process but ffi could not use it" or "AML did not load it (wrong mods folder, wrong ABI, or the file is broken)"); return false end
    if S.lib.hx_rpc_start(tostring(cfg.main.appid or "")) == 1 then
        S.started, S.err = true, ""
        return true
    end
    S.err = ffi.string(S.lib.hx_rpc_error())
    return false
end

-- ---------------------------------------------------------------- login flow
-- 1. "Log in with Discord": the core prepares a link, we open it in the browser (and copy it to the clipboard)
-- 2. approve in the browser; it then shows "can't be reached" for http://localhost/callback?code=...  (expected)
-- 3. copy that address, come back, press "Finish login": we read the clipboard and hand it to the core

local function beginLogin()
    if not start(true) then say("{ff0000}[RPC] {ffffff}" .. S.err); return end
    S.url = ""
    S.lib.hx_rpc_login()
    S.wantUrl, S.wantUntil = true, os.clock() + 25
    S.note = "Preparing the login..."
end

local function pollLoginUrl()
    if not S.wantUrl or not S.started then return end
    local n = S.lib.hx_rpc_login_url(S.urlbuf, 2048)
    if n > 0 then
        S.url, S.wantUrl = ffi.string(S.urlbuf, n), false
        S.lib.hx_rpc_clipboard_set(S.url)
        if openLink(S.url) then
            S.note = "The browser should open. Approve there, then copy the ADDRESS of the page that opens afterwards " ..
                     "(it says it can't be reached - that is expected) and come back."
        else
            S.note = "Could not open the browser by itself. The login link is on your clipboard: paste it into your browser."
        end
    elseif os.clock() > S.wantUntil then
        S.wantUrl = false      -- a saved login was restored instead (nothing to open), or the core reported an error
        S.note = ""
    end
end

local function finishLogin()
    if not S.started then return end
    local n = S.lib.hx_rpc_clipboard_get(S.clip, 4096)
    if n <= 0 then S.note = "The clipboard is empty: copy the address of the browser page first."; return end
    S.lib.hx_rpc_login_finish(ffi.string(S.clip, n))
    S.note = "Finishing the login..."
end

-- ---------------------------------------------------------------- SA-MP data

local function getMyId()
    local ok, found, id = pcall(sampGetPlayerIdByCharHandle, PLAYER_PED)
    if ok and found and type(id) == "number" then return id end
    return S.myId
end

local function snapshot()
    local okA, ip, port = pcall(sampGetCurrentServerAddress)
    if not okA or not ip or ip == "" then return nil end
    local id, nick = getMyId(), ""
    if id then
        local okN, n = pcall(sampGetPlayerNickname, id)
        if okN and n then nick = n end
    end
    local okS, server = pcall(sampGetCurrentServerName)
    local okP, players = pcall(sampGetPlayerCount, false)
    return { nick = nick, id = id or -1, server = (okS and server) or "", ip = ip,
             port = port or 7777, players = (okP and players) or 0 }
end

local function tick()
    if S.started then pollLoginUrl() end
    if not cfg.main.enabled then return end
    if not start() then return end
    local d = snapshot()
    if d then
        S.lastData, S.lostAt = d, 0
    elseif S.lastData then
        -- SA-MP data vanished (lag, reconnect, loading): keep the presence alive for `grace` seconds
        if S.lostAt == 0 then S.lostAt = os.clock() end
        if os.clock() - S.lostAt > (tonumber(cfg.main.grace) or 10) then
            S.lastData, S.lostAt, S.key = nil, 0, ""
            S.lib.hx_rpc_clear()
            return
        end
        d = S.lastData
    else
        return
    end
    local key = d.ip .. ":" .. d.port
    if key ~= S.key then S.key, S.startAt = key, os.time() end
    S.lib.hx_rpc_set_state(clean(toU8(d.nick)), d.id, clean(toU8(d.server)), clean(d.ip),
                           d.port, d.players, S.startAt)
end

require("samp.events").onInitGame = function(playerId) S.myId = playerId end

function onScriptTerminate(scr)
    if scr == thisScript() and S.lib and S.started then pcall(S.lib.hx_rpc_stop) end
end

-- ---------------------------------------------------------------- diagnostics

local function logTail(maxBytes)
    local dir = S.lib and ffi.string(S.lib.hx_rpc_work_dir()) or ""
    if dir == "" then return "" end
    local f = io.open(dir .. "/hxrpc.log", "rb")
    if not f then return "" end
    local size = f:seek("end") or 0
    f:seek("set", math.max(0, size - maxBytes))
    local s = f:read("*a") or ""
    f:close()
    if size > maxBytes then s = (s:gsub("^[^\n]*\n", "", 1)) end   -- first line is probably cut
    return s
end

local function diagnostics()
    return table.concat({
        "Hexed Discord RPC " .. thisScript().version,
        "status: " .. status(),
        "flags: " .. flags() .. "  started: " .. tostring(S.started),
        "error: " .. (S.err ~= "" and S.err or "none"),
        "mod: " .. (loadedLibPath() or "not in /proc/self/maps"),
        "load: " .. S_loadLog,
        "--- log ---",
        logTail(1500),
    }, "\n")
end

-- ---------------------------------------------------------------- menu (HEXED colors)

local THEME = {
    { "WindowBg",         0.016, 0.024, 0.102, 0.98 },
    { "TitleBg",          0.043, 0.071, 0.349, 1 },
    { "TitleBgActive",    0.106, 0.184, 0.941, 1 },
    { "Border",           0.169, 0.227, 0.659, 1 },
    { "Separator",        0.149, 0.188, 0.498, 1 },
    { "Button",           0.106, 0.184, 0.941, 0.90 },
    { "ButtonHovered",    0.192, 0.282, 1.000, 1 },
    { "ButtonActive",     0.039, 0.078, 0.659, 1 },
    { "FrameBg",          0.047, 0.071, 0.314, 1 },
    { "FrameBgHovered",   0.078, 0.114, 0.471, 1 },
    { "FrameBgActive",    0.106, 0.184, 0.941, 0.6 },
    { "CheckMark",        0.549, 0.620, 1.000, 1 },
    { "Header",           0.106, 0.184, 0.941, 0.55 },
    { "HeaderHovered",    0.192, 0.282, 1.000, 0.80 },
    { "HeaderActive",     0.106, 0.184, 0.941, 1 },
    { "Text",             0.957, 0.965, 1.000, 1 },
}
-- the style is pushed only around this window (does not touch other mimgui scripts); skipped if the names don't exist
local THEME_OK = pcall(function()
    for _, t in ipairs(THEME) do local _ = imgui.Col[t[1]] end
    local _ = imgui.StyleVar.WindowRounding
    local _ = imgui.StyleVar.FrameRounding
end)

local themeColors, themeVars = 0, 0

local function pushVar(var, val)
    local fn = imgui.PushStyleVarFloat or imgui.PushStyleVar     -- mimgui names it PushStyleVarFloat
    if not fn then return false end
    return pcall(fn, var, val)
end

local function pushTheme()
    themeColors, themeVars = 0, 0
    if not THEME_OK then return end
    for _, t in ipairs(THEME) do
        if pcall(imgui.PushStyleColor, imgui.Col[t[1]], imgui.ImVec4(t[2], t[3], t[4], t[5])) then
            themeColors = themeColors + 1
        end
    end
    if pushVar(imgui.StyleVar.WindowRounding, 12) then themeVars = themeVars + 1 end
    if pushVar(imgui.StyleVar.FrameRounding, 8) then themeVars = themeVars + 1 end
end

local function popTheme()
    if themeVars > 0 then imgui.PopStyleVar(themeVars) end
    if themeColors > 0 then imgui.PopStyleColor(themeColors) end
    themeColors, themeVars = 0, 0
end

local C_OK, C_WARN, C_BAD, C_MUTED =
    imgui.ImVec4(0.306, 0.878, 0.690, 1), imgui.ImVec4(1.0, 0.761, 0.4, 1),
    imgui.ImVec4(1.0, 0.549, 0.627, 1), imgui.ImVec4(0.663, 0.706, 0.902, 1)

local function statusColor(st)
    local s = st:lower()
    if s:find("retrying", 1, true) then return C_WARN end
    if s:find("failed", 1, true) or s:find("error", 1, true) or s:find("expired", 1, true) or s:find("not loaded", 1, true) then return C_BAD end
    if s:find("presence active", 1, true) or s:find("logged in", 1, true) then return C_OK end
    return C_MUTED
end

imgui.OnFrame(function() return S.win[0] end, function()
    pushTheme()
    imgui.SetNextWindowSize(imgui.ImVec2(440, 0), imgui.Cond.FirstUseEver)
    imgui.Begin("HEXED  Discord RPC", S.win)

    local f = flags()
    local st = status()
    imgui.TextColored(statusColor(st), st)
    imgui.TextColored(C_MUTED, "Account: " .. (has(f, F_READY) and "connected" or (has(f, F_SAVED) and "saved login" or "not logged in")))
    imgui.Separator()

    -- login
    if imgui.Button("Log in with Discord", imgui.ImVec2(-1, 0)) then beginLogin() end
    if has(f, F_WAITING) then
        imgui.TextWrapped("Step 2: approve in the browser, then COPY the address of the page that opens (it says it can't be reached - that is expected). Come back and press:")
        if imgui.Button("Finish login (use the copied address)", imgui.ImVec2(-1, 0)) then finishLogin() end
        if S.url ~= "" then
            if imgui.Button("Open the link again", imgui.ImVec2(-1, 0)) then
                if S.lib then S.lib.hx_rpc_clipboard_set(S.url) end
                openLink(S.url)
            end
        end
    end
    if S.note ~= "" then imgui.TextWrapped(S.note) end
    if imgui.Button("Log out (forget account)", imgui.ImVec2(-1, 0)) then
        if S.lib then S.lib.hx_rpc_logout() end
        S.note, S.wantUrl = "", false
    end
    imgui.Separator()

    local en = imgui.new.bool(cfg.main.enabled)
    if imgui.Checkbox("Rich presence enabled", en) then
        cfg.main.enabled = en[0]
        inicfg.save(cfg, INI)
        if not en[0] and S.lib and S.started then S.lib.hx_rpc_clear(); S.lastData, S.key = nil, "" end
    end
    if imgui.Button("HEXED STUDIO Discord", imgui.ImVec2(-1, 0)) then openLink(DISCORD_URL) end

    if imgui.CollapsingHeader("Diagnostics") then
        if S.err ~= "" then imgui.TextColored(C_BAD, S.err) end
        if S_loadLog ~= "" then imgui.TextWrapped(S_loadLog) end
        if os.clock() - S.logAt > 2 then S.logText, S.logAt = logTail(1200), os.clock() end
        imgui.TextWrapped(S.logText ~= "" and S.logText or "(no log yet)")
        if imgui.Button("Copy diagnostics to clipboard", imgui.ImVec2(-1, 0)) then
            if S.lib then S.lib.hx_rpc_clipboard_set(diagnostics()) end
            S.note = "Diagnostics copied: paste them where you report the problem."
        end
        if imgui.Button("Try the SDK device-code login (experimental)", imgui.ImVec2(-1, 0)) then
            if start(true) then S.lib.hx_rpc_login_device() end
        end
        if imgui.Button("Retry loading the mod", imgui.ImVec2(-1, 0)) then start(true) end
    end

    imgui.End()
    popTheme()
end)

function main()
    while not isSampLoaded() or not isSampfuncsLoaded() do wait(500) end
    while not isSampAvailable() do wait(100) end

    S.lib = loadLib()
    if start() then
        say("{1b2ff0}[HEXED] {ffffff}Discord RPC " .. thisScript().version .. " - /drpc")
    else
        say("{ff0000}[RPC] {ffffff}" .. S.err)
    end

    sampRegisterChatCommand("drpc", function() S.win[0] = not S.win[0] end)
    sampRegisterChatCommand("rpcdebug", function()
        say("[RPC] " .. status() .. " | flags=" .. flags() .. (S.err ~= "" and (" | err=" .. S.err) or ""))
    end)
    sampRegisterChatCommand("rpctoggle", function()
        cfg.main.enabled = not cfg.main.enabled
        inicfg.save(cfg, INI)
        if not cfg.main.enabled and S.lib and S.started then S.lib.hx_rpc_clear(); S.lastData, S.key = nil, "" end
        say("[RPC] enabled=" .. tostring(cfg.main.enabled))
    end)

    while true do
        wait(math.min(3000, math.max(250, tonumber(cfg.main.interval) or 1000)))
        pcall(tick)
    end
end
