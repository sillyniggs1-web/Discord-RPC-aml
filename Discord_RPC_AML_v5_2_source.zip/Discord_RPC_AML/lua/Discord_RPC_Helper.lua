script_name("Hexed Discord RPC Helper")
script_version("5.0")
-- OPTIONAL. v5 starts by itself ~10 s after the game loads. Use this only for the /rpcdebug command
-- (shows status in chat) or if auto-start did not work (/rpcstart tries again).
if script_properties then pcall(script_properties, "work-in-pause") end
require "lib.moonloader"
local ffi = require("ffi")
pcall(ffi.cdef, [[
    int         hx_rpc_start(void);
    const char* hx_rpc_error(void);
    const char* hx_rpc_probe(void);
    void        hx_rpc_resync(void);
    int         hx_rpc_status(char* out, int cap);
    int         hx_rpc_flags(void);
]])

local function loadLib()
    local f = io.open("/proc/self/maps", "r")
    local path
    if f then
        for line in f:lines() do
            local p = line:match("(/%S*%.so)%s*$")
            if p then
                local n = p:match("([^/]+)$"):lower()
                if n:find("discord", 1, true) and n:find("rpc", 1, true)
                   and not n:find("partner_sdk", 1, true) and not n:find("hxrpc_core", 1, true) then path = p; break end
            end
        end
        f:close()
    end
    for _, what in ipairs({ path, "libDiscord_RPC.so", "Discord_RPC" }) do
        if what then
            local ok, l = pcall(ffi.load, what)
            if ok and l then
                local ok2, fn = pcall(function() return l.hx_rpc_start end)
                if ok2 and fn then return l end
            end
        end
    end
end

local function say(m) sampAddChatMessage("{7289DA}[Discord RPC]{FFFFFF} " .. m, -1) end

function main()
    while not isSampLoaded() or not isSampfuncsLoaded() do wait(500) end
    while not isSampAvailable() do wait(100) end
    local lib = loadLib()
    local buf = ffi.new("char[512]")
    sampRegisterChatCommand("rpcdebug", function()
        if not lib then say("libDiscord_RPC.so not loaded (AML did not load the mod)"); return end
        lib.hx_rpc_status(buf, 512)
        say("status: " .. ffi.string(buf) .. " | flags=" .. lib.hx_rpc_flags())
        say("error: " .. ffi.string(lib.hx_rpc_error()))
        say("discord app: " .. ffi.string(lib.hx_rpc_probe()))
    end)
    sampRegisterChatCommand("rpcstart", function()
        if not lib then say("mod not loaded"); return end
        say(lib.hx_rpc_start() == 1 and "started / already running" or ("failed: " .. ffi.string(lib.hx_rpc_error())))
    end)
    sampRegisterChatCommand("rpcretry", function() if lib then lib.hx_rpc_resync(); say("resync sent") end end)
    wait(-1)
end
