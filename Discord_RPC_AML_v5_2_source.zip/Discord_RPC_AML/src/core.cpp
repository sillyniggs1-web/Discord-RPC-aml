// Hexed Discord RPC v5 - core library (libhxrpc_core_v5.so)                       [pure game activity]
// Discord Social SDK, NO login. Publishes ONE thing: "Playing <registered application name>" (+ optional timer).
// No details / state / images / party / buttons: Discord shows the application's own name and App Icon,
// the same way the desktop client shows a detected game.
// Path: Client::SetApplicationId + Client::UpdateRichPresence -> SDK RPC layer -> Discord app on this phone.

#define DISCORDPP_IMPLEMENTATION // exactly one file
#include "discordpp.h"

#include <jni.h>
#include <android/log.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "api.h"

#define TAG "HexedRPC"

namespace {

const long long kRetryMs = 8000;

std::atomic<bool> g_run{false};
std::thread g_thread;
std::mutex g_mu;
std::string g_status = "Stopped";
std::string g_logPath;
std::string g_name;                       // "" = registered application name

std::atomic<bool> g_ready{false};
std::atomic<bool> g_retry{false};
std::atomic<long long> g_retryAtMs{0};
std::atomic<bool> g_resync{false};
std::atomic<unsigned long long> g_appId{0};
std::atomic<bool> g_timer{true};
std::atomic<long long> g_startSec{0};     // game launch time, unix seconds

long long nowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

void logLine(const std::string& s) {
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", s.c_str());
    if (g_logPath.empty()) return;
    if (FILE* f = std::fopen(g_logPath.c_str(), "a")) {
        std::time_t t = std::time(nullptr);
        std::tm tmv{};
        localtime_r(&t, &tmv);
        char ts[16];
        std::strftime(ts, sizeof(ts), "%H:%M:%S", &tmv);
        std::fprintf(f, "%s core  %s\n", ts, s.c_str());
        std::fclose(f);
    }
}

void setStatus(const std::string& s) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        if (g_status == s) return;
        g_status = s;
    }
    logLine(s);
}

void push(const std::shared_ptr<discordpp::Client>& client) {
    discordpp::Activity a;
    a.SetType(discordpp::ActivityTypes::Playing);
    {
        std::lock_guard<std::mutex> lock(g_mu);
        if (!g_name.empty()) a.SetName(g_name);   // otherwise: registered application name
    }
    a.SetApplicationId(g_appId.load());           // this id decides the game name + App Icon Discord shows
    a.SetStatusDisplayType(discordpp::StatusDisplayTypes::Name);
    a.SetSupportedPlatforms(static_cast<discordpp::ActivityGamePlatforms>(
        static_cast<int>(discordpp::ActivityGamePlatforms::Desktop) |
        static_cast<int>(discordpp::ActivityGamePlatforms::Android) |
        static_cast<int>(discordpp::ActivityGamePlatforms::IOS)));
    if (g_timer && g_startSec > 0) {
        discordpp::ActivityTimestamps ts;
        ts.SetStart(static_cast<uint64_t>(g_startSec.load()));
        a.SetTimestamps(ts);
    }
    client->UpdateRichPresence(a, [](discordpp::ClientResult r) {
        if (r.Successful()) {
            g_ready = true;
            g_retry = false;
            setStatus("Playing (game activity active)");
        } else {
            g_ready = false;
            g_retry = true;
            g_retryAtMs = nowMs() + kRetryMs;
            setStatus("Discord app not reachable (retrying): " + std::string(r.Error()));
        }
    });
}

void worker(uint64_t appId) {
    using clock = std::chrono::steady_clock;
    using std::chrono::seconds;

    auto client = std::make_shared<discordpp::Client>();
    client->AddLogCallback([](auto message, auto) { logLine("[sdk] " + std::string(message)); },
                           discordpp::LoggingSeverity::Info);
    client->SetApplicationId(appId);

    bool first = true;
    auto lastPush = clock::time_point{};
    while (g_run) {
        const auto now = clock::now();
        bool due = first || now - lastPush > seconds(30);   // 30 s keep-alive
        if (g_resync.exchange(false)) { due = true; g_retry = false; }
        if (g_retry && nowMs() >= g_retryAtMs.load()) { due = true; g_retry = false; }
        if (due) {
            push(client);
            first = false;
            lastPush = now;
        }
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    client->ClearRichPresence();
    for (int i = 0; i < 5; ++i) {
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

} // namespace

static int c_start(unsigned long long appId, const char* dir, int showTimer, const char* nameOverride) {
    if (g_run.exchange(true)) return 1;
    const std::string d = dir ? dir : ".";
    g_logPath = d + "/hxrpc.log";
    g_ready = false; g_retry = false; g_resync = false;
    if (g_thread.joinable()) g_thread.join();
    g_appId = appId;
    g_timer = showTimer != 0;
    g_startSec = static_cast<long long>(std::time(nullptr));
    {
        std::lock_guard<std::mutex> lock(g_mu);
        g_name = nameOverride ? nameOverride : "";
    }
    logLine("core start (pure game activity), app id " + std::to_string(appId) +
            ", timer " + (showTimer ? "on" : "off") + ", name " + (nameOverride && *nameOverride ? nameOverride : "(registered)"));
    g_thread = std::thread(worker, static_cast<uint64_t>(appId));
    return 1;
}

static void c_stop() {
    g_run = false;
    if (g_thread.joinable()) g_thread.join();
    g_ready = false;
    setStatus("Stopped");
}

static void c_resync() { g_resync = true; }

static int c_status(char* out, int cap) {
    if (!out || cap <= 0) return 0;
    std::lock_guard<std::mutex> lock(g_mu);
    std::snprintf(out, static_cast<size_t>(cap), "%s", g_status.c_str());
    return static_cast<int>(std::strlen(out));
}

static int c_flags() {
    int f = 0;
    if (g_ready) f |= 1;
    if (g_run) f |= 2;
    if (g_retry) f |= 4;
    return f;
}

static HxApi g_api = { HX_API_VERSION, c_start, c_stop, c_resync, c_status, c_flags };

extern "C" JNIEXPORT jlong JNICALL Java_com_hexed_rpc_HxBridge_apiTable(JNIEnv*, jclass) {
    return static_cast<jlong>(reinterpret_cast<intptr_t>(&g_api));
}
