// Function table shared by the stub (libDiscord_RPC.so) and the core (libhxrpc_core_v5.so).
// v5: "pure activity" - no custom text/images/buttons/party. Only the registered game + optional elapsed timer.
#pragma once
#define HX_API_VERSION 5
// flags(): bit0 = the Discord app accepted the last presence, bit1 = core running, bit2 = retrying (Discord app not reachable)
struct HxApi {
    int  version;
    // appId: Discord application id. showTimer: 1 = send the "playing for X minutes" start time.
    // nameOverride: "" = Discord shows the application's registered name (what we want).
    int  (*start)(unsigned long long appId, const char* dir, int showTimer, const char* nameOverride);
    void (*stop)();
    void (*resync)();                         // push again right now
    int  (*status)(char* out, int cap);
    int  (*flags)();
};
