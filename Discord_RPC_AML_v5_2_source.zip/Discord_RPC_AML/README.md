# Hexed Discord RPC v5.2 - pure game activity (no custom presence)

v5 throws away everything custom: no server name, nick, IP, images, party, buttons, no menu, no Lua required.
The mod does exactly one thing: while the game is running, the Discord app on the same phone shows
**"Playing <your Discord application's registered name>"** with its App Icon (+ an optional "for X minutes" timer).
That is the closest a phone can get to what the Discord PC client shows for a detected game.

```
game starts -> AML loads libDiscord_RPC.so -> ~10 s later it starts by itself
  -> core + Discord Social SDK: SetApplicationId + UpdateRichPresence(type=Playing, appId, timer)  (nothing else)
  -> Discord app on this phone -> your profile
```

## Application id (v5.1)
The built-in id is now **363447565905166336**, the id you gave me for Discord's own "Grand Theft Auto: San Andreas" entry
(I could not verify it myself). Discord then takes the name, icon and game page from its own database, not from your app.
**Unverified:** the Social SDK header says an activity's application id is always the current game's or one from the same
publisher, so the SDK or the Discord app may ignore or refuse this id. Check the log: `core start ... app id 363447565905166336`,
then `Playing (game activity active)`. If it is refused, put your own application id in `appid =` (rename that application
to "Grand Theft Auto: San Andreas" and upload the icon in the Developer Portal), then force stop Discord.


## Install (armeabi-v7a for Nezuko)
```
<AML mods folder>/libDiscord_RPC.so
<AML mods folder>/Discord_RPC/            <- keep next to the .so
        libhxrpc_core_v5.so
        libdiscord_partner_sdk.so
        hx_dex_v3.jar
```
Delete the old v4 files (`libhxrpc_core_v4.so`, old `Discord_RPC.lua`, `Hexed DiscordRpc.ini`): they are not used any more.
`Discord_RPC/Discord_RPC.ini` is created on first run:
```
enabled = 1      ; 0 = do nothing
appid =          ; empty = built-in 363447565905166336 (GTA San Andreas, supplied by the user)
timer = 1        ; "playing for X minutes"
name = Grand Theft Auto: San Andreas   ; activity name (empty = this same default)
```
Optional: `Discord_RPC_Helper.lua` (MonetLoader scripts folder) only adds `/rpcdebug` (status in chat), `/rpcstart`, `/rpcretry`.

## Build
Same as v4: push the folder, run **Actions -> Build Discord_RPC AML mod**, take the `Discord_RPC_AML` artifact.

## Test plan
1. Discord app installed, signed in, opened once. Modloader ON. Copy files, start the game.
2. Wait ~15 s. Your Discord profile should show Playing <app name> with the timer. If not: `/rpcdebug` (helper) or `files/hxrpc/hxrpc.log`
   (private storage; look for `auto-start ok`, `core start (pure game activity)`, `Playing (game activity active)`).
3. Quit the game: the activity should clear.

## Status
Checked: `core.cpp` compiles (syntax) against the real `discordpp.h` with mock JNI/log headers; `stub.cpp`'s own code has no errors
(the AML headers were only partly mockable). NOT checked: NDK/CMake build, d8, anything on a phone. Unknown: whether the Discord app accepts an
activity that has no details/state (the SDK allows it), and whether `GetCurrentContext()` works from the delayed background thread
(v4 called it from the Lua thread). If auto-start logs `no app context from AML`, use the helper's `/rpcstart`.

## v5.2: why Discord showed "Game"
With application id 363447565905166336 Discord showed the right icon but the name "Game": the SDK path sent no activity name, and
the Discord app did not look the name up from the id. v5.2 always sends the name (default "Grand Theft Auto: San Andreas", editable via `name =`).
Existing INI files from v5/v5.1 have `name =` empty: that now also means the default.
