script_name("Hexed Discord RPC")
script_author("HEXED Studio")
script_version("2.1")

-- Lua side of the Discord_RPC AML mod: reads the SA-MP info and hands it to libDiscord_RPC.so over FFI.
-- (replaces Discord_RPC_Bridge.lua + the SampDiscordRpc companion app: no UDP, no second APK)

if script_properties then pcall(script_properties, "work-in-pause") end

require "lib.moonloader"
local ffi      = require("ffi")
local imgui    = require("mimgui")
local inicfg   = require("inicfg")
local encoding = require("encoding")
encoding.default = "CP1251"
local u8 = encoding.UTF8

local INI = "Hexed DiscordRpc.ini"
local cfg = inicfg.load({ main = { enabled = true, appid = "", interval = 1000, grace = 10 } }, INI)
inicfg.save(cfg, INI)

pcall(ffi.cdef, [[
    int         hx_rpc_start(const char* appId);
    const char* hx_rpc_error(void);
    void        hx_rpc_stop(void);
    void        hx_rpc_clear(void);
    void        hx_rpc_login(void);
    void        hx_rpc_logout(void);
    void        hx_rpc_set_state(const char* nick, int id, const char* server, const char* ip,
                                 int port, int players, long long start);
    int         hx_rpc_status(char* out, int cap);
    int         hx_rpc_flags(void);
]])

-- opening links: same approach as CameraSettings.lua, the game's own AND_OpenLink (no Java needed)
pcall(ffi.cdef, "void _Z12AND_OpenLinkPKc(const char* link);")
local okGta, gta = pcall(ffi.load, "GTASA")
local DISCORD_URL = "https://discord.gg/MmqnsXg2QC"

local function openLink(link)
    if okGta and gta then pcall(function() gta._Z12AND_OpenLinkPKc(link) end) end
end

local S = {
    lib = nil, started = false, startAt = 0, key = "", myId = nil,
    lastData = nil, lostAt = 0, win = imgui.new.bool(false),
    buf = ffi.new("char[512]"), err = "", setupMsg = "", soPath = nil,
    nextStart = 0, nextSetup = 0, loginAt = 0,
}

local function loadLib()
    for _, name in ipairs({ "libDiscord_RPC.so", "Discord_RPC" }) do
        local ok, l = pcall(ffi.load, name)
        if ok and l then return l end
    end
    return nil
end

-- ---------------------------------------------------------------- support folder (Discord_RPC/)
-- libDiscord_RPC.so looks for Discord_RPC/{libhxrpc_core.so, libdiscord_partner_sdk.so, hx_dex.jar} next to the
-- place AML LOADED it from. AML does not always load it from the folder you copied it to, so this finds the real
-- location (from /proc/self/maps), finds your Discord_RPC folder and puts a copy where the mod looks.
local SUPPORT = { "libhxrpc_core.so", "libdiscord_partner_sdk.so", "hx_dex.jar" }

local function fileSize(p)
    local f = io.open(p, "rb")
    if not f then return nil end
    local n = f:seek("end")
    f:close()
    return type(n) == "number" and n or nil
end

local function dirOf(p) return (tostring(p):gsub("/[^/]*$", "")) end

local function missingIn(dir)
    local miss = {}
    for _, n in ipairs(SUPPORT) do
        local sz = fileSize(dir .. "/" .. n)
        if not sz or sz <= 0 then miss[#miss + 1] = n end
    end
    return miss
end

local function loadedLibPath()
    local f = io.open("/proc/self/maps", "r")
    if not f then return nil end
    local found
    for line in f:lines() do
        local p = line:match("(/.*libDiscord_RPC%.so)")
        if p then found = p; break end
    end
    f:close()
    return found
end

local function packageName()
    local f = io.open("/proc/self/cmdline", "rb")
    if not f then return nil end
    local s = f:read("*a") or ""
    f:close()
    return s:match("^[^%z]+")
end

local function listSubdirs(path)
    local out = {}
    local ok, ph = pcall(io.popen, 'ls -1 "' .. path .. '" 2>/dev/null')
    if ok and ph then
        for l in ph:lines() do out[#out + 1] = path .. "/" .. l end
        ph:close()
    end
    return out
end

local function candidateRoots(soDir)
    local roots, seen = {}, {}
    local function add(r)
        if r and r ~= "" and not seen[r] then seen[r] = true; roots[#roots + 1] = r end
    end
    add(soDir)
    local okS, sp = pcall(function() return thisScript().path end)
    if okS and sp then add(dirOf(sp)); add(dirOf(dirOf(sp))) end
    local okW, wd = pcall(getWorkingDirectory)
    if okW and wd then add(wd); add(wd .. "/mods"); add(wd .. "/AMLMods"); add(dirOf(wd)) end
    local pkg = packageName()
    for _, base in ipairs({ "/storage/emulated/0", "/sdcard" }) do
        add(base .. "/AMLMods")
        for _, sub in ipairs(listSubdirs(base .. "/AMLMods")) do
            add(sub)
            add(sub .. "/mods")
        end
        if pkg then
            add(base .. "/Android/data/" .. pkg .. "/files")
            add(base .. "/Android/data/" .. pkg .. "/files/mods")
            add(base .. "/Android/data/" .. pkg .. "/files/AMLMods")
        end
    end
    return roots
end

local function copyFile(from, to)
    local i = io.open(from, "rb")
    if not i then return false, "cannot read " .. from end
    local o, e = io.open(to, "wb")
    if not o then i:close(); return false, "cannot write " .. to .. " (" .. tostring(e) .. ")" end
    while true do
        local chunk = i:read(65536)
        if not chunk then break end
        o:write(chunk)
    end
    i:close(); o:close()
    return true
end

local function makeDir(path)
    pcall(function() createDirectory(path) end)
    if not fileSize(path .. "/.") then pcall(os.execute, 'mkdir -p "' .. path .. '"') end
end

-- returns true when the support files sit where the mod looks for them
local function ensureSupport()
    local so = loadedLibPath()
    S.soPath = so
    if not so then
        S.setupMsg = "libDiscord_RPC.so is not loaded by AML (not in /proc/self/maps)"
        return false
    end
    local dst = dirOf(so) .. "/Discord_RPC"
    if #missingIn(dst) == 0 then
        S.setupMsg = "support files OK: " .. dst
        return true
    end
    local tried, src = {}, nil
    for _, r in ipairs(candidateRoots(dirOf(so))) do
        for _, d in ipairs({ r .. "/Discord_RPC", r }) do
            if d ~= dst and #missingIn(d) == 0 then src = d; break end
            tried[#tried + 1] = d
        end
        if src then break end
    end
    if not src then
        S.setupMsg = "AML loaded the mod from " .. so .. " but " .. table.concat(missingIn(dst), ", ") ..
            " missing in " .. dst .. " and no Discord_RPC folder was found anywhere else. Copy the whole Discord_RPC folder to " ..
            dirOf(so) .. "/ (looked in " .. #tried .. " places)"
        return false
    end
    makeDir(dst)
    for _, n in ipairs(SUPPORT) do
        local sa, sb = fileSize(src .. "/" .. n), fileSize(dst .. "/" .. n)
        if sa ~= sb then
            local ok, why = copyFile(src .. "/" .. n, dst .. "/" .. n)
            if not ok then S.setupMsg = "could not set up support files: " .. why; return false end
        end
    end
    local still = missingIn(dst)
    if #still > 0 then S.setupMsg = "copy finished but still missing: " .. table.concat(still, ", "); return false end
    S.setupMsg = "support files copied from " .. src .. " to " .. dst
    return true
end

local function say(msg) sampAddChatMessage(msg, -1) end
local function toU8(s) local ok, r = pcall(u8, s); return (ok and r) or s end
local function clean(s) return (tostring(s or ""):gsub("[\t\r\n]", " ")) end

local function status()
    if not S.lib then return "libDiscord_RPC.so not loaded (is the AML mod installed?)" end
    S.lib.hx_rpc_status(S.buf, 512)
    return ffi.string(S.buf)
end

local function flags() return S.lib and S.lib.hx_rpc_flags() or 0 end

local function start(force)
    if S.started then return true end
    if not force and os.clock() < S.nextStart then return false end
    S.nextStart = os.clock() + 15      -- a failed start is retried every 15 s, or at once from the menu
    if not S.lib then S.lib = loadLib() end
    if not S.lib then S.err = "libDiscord_RPC.so not found"; return false end
    -- the support files must be in place BEFORE the mod's first start attempt
    if not ensureSupport() and S.soPath then S.err = S.setupMsg; return false end
    if S.lib.hx_rpc_start(tostring(cfg.main.appid or "")) == 1 then
        S.started, S.err = true, ""
        return true
    end
    S.err = ffi.string(S.lib.hx_rpc_error())
    return false
end

local function getMyId()
    local ok, found, id = pcall(sampGetPlayerIdByCharHandle, PLAYER_PED)
    if ok and found and type(id) == "number" then return id end
    return S.myId
end

local function snapshot()
    local okA, ip, port = pcall(sampGetCurrentServerAddress)
    if not okA or not ip or ip == "" then return nil end
    local id, nick = getMyId(), ""
    if id then
        local okN, n = pcall(sampGetPlayerNickname, id)
        if okN and n then nick = n end
    end
    local okS, server = pcall(sampGetCurrentServerName)
    local okP, players = pcall(sampGetPlayerCount, false)
    return { nick = nick, id = id or -1, server = (okS and server) or "", ip = ip,
             port = port or 7777, players = (okP and players) or 0 }
end

local function tick()
    if not cfg.main.enabled then return end
    if not start() then return end
    local d = snapshot()
    if d then
        S.lastData, S.lostAt = d, 0
    elseif S.lastData then
        if S.lostAt == 0 then S.lostAt = os.clock() end
        if os.clock() - S.lostAt > (tonumber(cfg.main.grace) or 10) then
            S.lastData, S.lostAt, S.key = nil, 0, ""
            S.lib.hx_rpc_clear()
            return
        end
        d = S.lastData
    else
        return
    end
    local key = d.ip .. ":" .. d.port
    if key ~= S.key then S.key, S.startAt = key, os.time() end
    S.lib.hx_rpc_set_state(clean(toU8(d.nick)), d.id, clean(toU8(d.server)), clean(d.ip),
                           d.port, d.players, S.startAt)
end

require("samp.events").onInitGame = function(playerId) S.myId = playerId end

function onScriptTerminate(scr)
    if scr == thisScript() and S.lib and S.started then pcall(S.lib.hx_rpc_stop) end
end

-- ---------------------------------------------------------------- menu
imgui.OnFrame(function() return S.win[0] end, function()
    imgui.SetNextWindowSize(imgui.ImVec2(420, 0), imgui.Cond.FirstUseEver)
    imgui.Begin("Hexed Discord RPC", S.win)
    local f = flags()
    imgui.TextWrapped(status())
    imgui.Separator()
    imgui.Text("Account: " .. (bit.band(f, 1) ~= 0 and "connected" or (bit.band(f, 4) ~= 0 and "saved login" or "not logged in")))
    if imgui.Button("Log in with Discord", imgui.ImVec2(-1, 0)) then
        if start(true) then
            S.lib.hx_rpc_login()
            S.loginAt = os.clock()
        else
            say("{ff0000}[RPC] {ffffff}" .. S.err)
        end
    end
    if S.loginAt > 0 and os.clock() - S.loginAt < 20 and bit.band(f, 1) == 0 then
        imgui.TextWrapped("Waiting for Discord... a Discord / browser screen should open. If nothing opens, the status line above says why.")
    end
    if imgui.Button("Log out (forget account)", imgui.ImVec2(-1, 0)) then
        if S.lib then S.lib.hx_rpc_logout() end
    end
    local en = imgui.new.bool(cfg.main.enabled)
    if imgui.Checkbox("Rich presence enabled", en) then
        cfg.main.enabled = en[0]
        inicfg.save(cfg, INI)
        if not en[0] and S.lib and S.started then S.lib.hx_rpc_clear(); S.lastData, S.key = nil, "" end
    end
    imgui.Separator()
    if imgui.Button("HEXED STUDIO Discord", imgui.ImVec2(-1, 0)) then openLink(DISCORD_URL) end
    imgui.Separator()
    if imgui.Button("Check / fix support files", imgui.ImVec2(-1, 0)) then
        if not S.started then start(true) else ensureSupport() end
    end
    if S.soPath then imgui.TextWrapped("Mod loaded from: " .. S.soPath) end
    if S.setupMsg ~= "" then imgui.TextWrapped("Setup: " .. S.setupMsg) end
    if S.err ~= "" then imgui.TextWrapped("Error: " .. S.err) end
    imgui.End()
end)

function main()
    while not isSampLoaded() or not isSampfuncsLoaded() do wait(500) end
    while not isSampAvailable() do wait(100) end

    S.lib = loadLib()
    if start() then
        say("{ff0000}[INFO] {ffffff}Hexed Discord RPC " .. thisScript().version .. " - /drpc")
    else
        say("{ff0000}[RPC] {ffffff}" .. S.err)
    end

    sampRegisterChatCommand("drpc", function() S.win[0] = not S.win[0] end)
    sampRegisterChatCommand("rpcdebug", function()
        say("[RPC] " .. status() .. " | flags=" .. flags() .. (S.err ~= "" and (" | err=" .. S.err) or "") .. (S.setupMsg ~= "" and (" | setup=" .. S.setupMsg) or ""))
    end)
    sampRegisterChatCommand("rpctoggle", function()
        cfg.main.enabled = not cfg.main.enabled
        inicfg.save(cfg, INI)
        if not cfg.main.enabled and S.lib and S.started then S.lib.hx_rpc_clear(); S.lastData, S.key = nil, "" end
        say("[RPC] enabled=" .. tostring(cfg.main.enabled))
    end)

    while true do
        wait(math.min(3000, math.max(250, tonumber(cfg.main.interval) or 1000)))
        pcall(tick)
    end
end

if rawget(_G, "HEXED_RPC_TEST") then
    _G.HEXED_RPC_TEST = { S = S, ensureSupport = ensureSupport, start = start, loadedLibPath = loadedLibPath, missingIn = missingIn }
end
