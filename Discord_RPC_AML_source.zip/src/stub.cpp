// Hexed Discord RPC - AML mod (libDiscord_RPC.so)
// This is the file AML loads. It stays small on purpose and has no link dependency on the Discord SDK:
//   1. finds the support files (core, SDK, dex) - next to this .so in Discord_RPC/, or in any AML mods folder -
//      and copies them into the app's private dir
//   2. builds a DexClassLoader with the SDK's Java classes + HxBridge
//   3. HxBridge gives the SDK its Activity and System.load()s the core through that loader
//   4. fetches the core's function table and exposes it to Lua over plain C (FFI)

#include "mod/amlmod.h"
#include <jni.h>
#include <android/log.h>
#include <dirent.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include "api.h"

#ifndef HX_DEFAULT_APP_ID
#define HX_DEFAULT_APP_ID 0ULL
#endif

#define TAG "HexedRPC"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

MYMOD(net.hexedstudio.discordrpc, Hexed Discord RPC, 1.1.0, HEXED Studio)

namespace {

std::mutex g_mu;
bool g_javaFailed = false;   // Java stage failed: a second try in the same process cannot work, needs a game restart
HxApi* g_api = nullptr;
char g_err[512] = "not started";
std::string g_work;   // <filesDir>/hxrpc, also where the saved Discord login lives

void setErr(const std::string& s) {
    std::snprintf(g_err, sizeof(g_err), "%s", s.c_str());
    LOGE("%s", g_err);
}

// Java-stage failure: remember it, a retry would only hit "Could not initialize class"
bool failJava(const std::string& s) {
    g_javaFailed = true;
    setErr(s + " (restart the game after fixing this)");
    return false;
}

std::string modDir() {
    Dl_info info{};
    if (!dladdr(reinterpret_cast<void*>(&modDir), &info) || !info.dli_fname) return ".";
    std::string p = info.dli_fname;
    auto slash = p.find_last_of('/');
    return slash == std::string::npos ? "." : p.substr(0, slash);
}

const char* const kSdk  = "libdiscord_partner_sdk.so";
const char* const kCore = "libhxrpc_core.so";
const char* const kDex  = "hx_dex.jar";

bool fileOk(const std::string& p) {
    struct stat st{};
    return stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0 && access(p.c_str(), R_OK) == 0;
}

bool dirHasSupport(const std::string& d) {
    return fileOk(d + "/" + kSdk) && fileOk(d + "/" + kCore) && fileOk(d + "/" + kDex);
}

std::string missingIn(const std::string& d) {
    std::string m;
    for (const char* f : { kSdk, kCore, kDex })
        if (!fileOk(d + "/" + f)) m += std::string(m.empty() ? "" : ", ") + f;
    return m;
}

// "" = ok, otherwise what went wrong (with errno)
std::string copyFile(const std::string& from, const std::string& to, mode_t mode) {
    FILE* in = std::fopen(from.c_str(), "rb");
    if (!in) return "cannot read " + from + " (" + std::strerror(errno) + ")";
    std::fseek(in, 0, SEEK_END);
    long size = std::ftell(in);
    std::fseek(in, 0, SEEK_SET);
    struct stat a{}, b{};
    if (stat(to.c_str(), &b) == 0 && b.st_size == size && stat(from.c_str(), &a) == 0 && b.st_mtime >= a.st_mtime) {
        std::fclose(in);
        return "";   // already current
    }
    unlink(to.c_str());   // may be read-only
    FILE* out = std::fopen(to.c_str(), "wb");
    if (!out) { std::string e = std::strerror(errno); std::fclose(in); return "cannot write " + to + " (" + e + ")"; }
    char buf[1 << 15];
    size_t n;
    bool ok = true;
    while ((n = std::fread(buf, 1, sizeof(buf), in)) > 0)
        if (std::fwrite(buf, 1, n, out) != n) { ok = false; break; }
    std::fclose(in);
    if (std::fclose(out) != 0) ok = false;
    if (!ok) return "write failed for " + to + " (" + std::strerror(errno) + ")";
    chmod(to.c_str(), mode);
    return "";
}

// ---- where are the support files? -------------------------------------------------------------
// AML may load this .so from a different place than the folder the user copied it to (some AML
// versions copy mods into private storage first), so "next to the .so" is only the first guess.

std::vector<std::string> baseDirs() {
    std::vector<std::string> b;
    auto add = [&](const std::string& raw) {
        std::string s = raw;
        while (s.size() > 1 && s.back() == '/') s.pop_back();
        if (s.empty()) return;
        for (const auto& x : b) if (x == s) return;
        b.push_back(s);
    };
    auto addc = [&](const char* p) { if (p && *p) add(p); };
    add(modDir());
    addc(aml->GetInternalModsPath());
    addc(aml->GetAndroidDataPath());
    addc(aml->GetAndroidDataRootPath());
    addc(aml->GetConfigPath());
    addc(aml->GetDataPath());
    return b;
}

void scanDirs(const std::string& root, int depth, int& budget, std::vector<std::string>& found) {
    if (depth < 0 || budget <= 0 || found.size() >= 4) return;
    --budget;
    if (dirHasSupport(root + "/Discord_RPC")) found.push_back(root + "/Discord_RPC");
    DIR* d = opendir(root.c_str());
    if (!d) return;
    while (dirent* e = readdir(d)) {
        if (e->d_name[0] == '.') continue;
        if (e->d_type == DT_DIR || e->d_type == DT_UNKNOWN) scanDirs(root + "/" + e->d_name, depth - 1, budget, found);
        if (found.size() >= 4 || budget <= 0) break;
    }
    closedir(d);
}

// returns the folder holding all three files, "" if none; `tried` lists what was checked
std::string findSupportDir(std::string& tried) {
    const auto bases = baseDirs();
    auto check = [&](const std::string& dir) {
        if (dirHasSupport(dir)) return true;
        if (tried.size() < 300) tried += (tried.empty() ? "" : " | ") + dir;
        return false;
    };
    for (const auto& b : bases) {
        if (check(b + "/Discord_RPC")) return b + "/Discord_RPC";
        if (check(b)) return b;
    }
    int budget = 1500;
    std::vector<std::string> found;
    for (const auto& b : bases) {
        scanDirs(b, 3, budget, found);
        if (!found.empty()) break;
    }
    return found.empty() ? std::string() : found.front();
}

// description of a pending Java exception, then clear it
std::string takeException(JNIEnv* env) {
    if (!env->ExceptionCheck()) return "";
    jthrowable t = env->ExceptionOccurred();
    env->ExceptionClear();
    std::string out = "Java exception";
    jclass tc = env->FindClass("java/lang/Throwable");
    jmethodID ts = env->GetMethodID(tc, "toString", "()Ljava/lang/String;");
    if (ts && t) {
        jstring js = (jstring)env->CallObjectMethod(t, ts);
        if (js) {
            const char* c = env->GetStringUTFChars(js, nullptr);
            if (c) { out = c; env->ReleaseStringUTFChars(js, c); }
        }
    }
    env->ExceptionClear();
    return out;
}

std::string javaString(JNIEnv* env, jobject obj, const char* method) {
    jclass c = env->GetObjectClass(obj);
    jmethodID m = env->GetMethodID(c, method, "()Ljava/lang/String;");
    if (!m) { env->ExceptionClear(); return ""; }
    jstring s = (jstring)env->CallObjectMethod(obj, m);
    if (!s) return "";
    const char* c8 = env->GetStringUTFChars(s, nullptr);
    std::string r = c8 ? c8 : "";
    if (c8) env->ReleaseStringUTFChars(s, c8);
    return r;
}

bool bootstrap() {
    JavaVM* vm = aml->GetJavaVM();
    if (!vm) { setErr("AML gave no JavaVM"); return false; }
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) { setErr("AttachCurrentThread failed"); return false; }
    }
    jobject ctx = aml->GetCurrentContext();
    if (!ctx) { setErr("no app context from AML"); return false; }

    // --- private working dir: <filesDir>/hxrpc
    jclass ctxCls = env->GetObjectClass(ctx);
    jmethodID getFiles = env->GetMethodID(ctxCls, "getFilesDir", "()Ljava/io/File;");
    jobject filesDir = env->CallObjectMethod(ctx, getFiles);
    if (!filesDir) { setErr("getFilesDir failed"); return false; }
    const std::string work = javaString(env, filesDir, "getAbsolutePath") + "/hxrpc";
    g_work = work;
    mkdir(work.c_str(), 0700);
    mkdir((work + "/odex").c_str(), 0700);

    // --- find the support files and copy them out of the mods folder
    std::string tried;
    const std::string src = findSupportDir(tried);
    if (!src.empty()) {
        LOGI("support files found in %s", src.c_str());
        for (const char* f : { kSdk, kCore, kDex }) {
            const std::string e = copyFile(src + "/" + f, work + "/" + f, std::strcmp(f, kDex) == 0 ? 0444 : 0755);
            if (!e.empty()) { setErr(e); return false; }
        }
    } else if (dirHasSupport(work)) {
        LOGI("support folder not found, reusing the files copied earlier in %s", work.c_str());
    } else {
        const std::string first = modDir() + "/Discord_RPC";
        setErr("Support files not found (" + missingIn(first) + " missing in " + first + "). Mod was loaded from " +
               modDir() + ". Looked in: " + tried);
        return false;   // not a Java failure: fix the files and press Log in again
    }

    // --- DexClassLoader(dexPath, odexDir, libDir, parent = the game's loader)
    jmethodID getLoader = env->GetMethodID(ctxCls, "getClassLoader", "()Ljava/lang/ClassLoader;");
    jobject parent = env->CallObjectMethod(ctx, getLoader);
    jclass dcl = env->FindClass("dalvik/system/DexClassLoader");
    jmethodID dclInit = env->GetMethodID(dcl, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
    jstring jDex = env->NewStringUTF((work + "/hx_dex.jar").c_str());
    jstring jOpt = env->NewStringUTF((work + "/odex").c_str());
    jstring jLib = env->NewStringUTF(work.c_str());
    jobject loader = env->NewObject(dcl, dclInit, jDex, jOpt, jLib, parent);
    if (!loader) return failJava("DexClassLoader: " + takeException(env));

    jmethodID loadClass = env->GetMethodID(dcl, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    jstring jName = env->NewStringUTF("com.hexed.rpc.HxBridge");
    jclass bridge = (jclass)env->CallObjectMethod(loader, loadClass, jName);
    if (!bridge) return failJava("loadClass HxBridge: " + takeException(env));
    bridge = (jclass)env->NewGlobalRef(bridge);

    // --- HxBridge.init(ctx, corePath)
    jmethodID init = env->GetStaticMethodID(bridge, "init",
        "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    if (!init) return failJava("HxBridge.init not found (hx_dex.jar is older than libDiscord_RPC.so): " + takeException(env));
    jstring jSdk  = env->NewStringUTF((work + "/" + kSdk).c_str());
    jstring jCore = env->NewStringUTF((work + "/" + kCore).c_str());
    jstring res = (jstring)env->CallStaticObjectMethod(bridge, init, ctx, jSdk, jCore);
    if (env->ExceptionCheck()) return failJava("HxBridge.init: " + takeException(env));
    if (res) {
        const char* c = env->GetStringUTFChars(res, nullptr);
        const std::string msg = std::string("HxBridge.init: ") + (c ? c : "?");
        if (c) env->ReleaseStringUTFChars(res, c);
        return failJava(msg);
    }

    // --- HxBridge.apiTable() -> function table inside the core
    jmethodID tbl = env->GetStaticMethodID(bridge, "apiTable", "()J");
    jlong addr = tbl ? env->CallStaticLongMethod(bridge, tbl) : 0;
    if (env->ExceptionCheck()) return failJava("apiTable: " + takeException(env));
    g_api = reinterpret_cast<HxApi*>(static_cast<intptr_t>(addr));
    if (!g_api || g_api->version != HX_API_VERSION) { g_api = nullptr; return failJava("core API mismatch"); }

    std::snprintf(g_err, sizeof(g_err), "ok");
    LOGI("bootstrap ok, work dir %s", work.c_str());
    return true;
}

HxApi* api() {
    std::lock_guard<std::mutex> lock(g_mu);
    return g_api;
}

} // namespace

extern "C" {

// ---- exported for Lua (ffi.load) -------------------------------------------------------------
// returns 1 on success; on failure hx_rpc_error() says why. Safe to call again after fixing missing files. appId: decimal string, "" = built-in default.
__attribute__((visibility("default"))) int hx_rpc_start(const char* appId) {
    {
        std::lock_guard<std::mutex> lock(g_mu);
        if (!g_api) {
            if (g_javaFailed) return 0;          // error text stays; needs a game restart
            if (!bootstrap()) return 0;          // file problems are retried on the next call
        }
    }
    unsigned long long id = (appId && *appId) ? std::strtoull(appId, nullptr, 10) : HX_DEFAULT_APP_ID;
    if (id == 0) { setErr("no Discord application id"); return 0; }
    return g_api->start(id, g_work.c_str());
}
__attribute__((visibility("default"))) const char* hx_rpc_error() { return g_err; }
__attribute__((visibility("default"))) void hx_rpc_stop()  { if (auto* a = api()) a->stop(); }
__attribute__((visibility("default"))) void hx_rpc_clear() { if (auto* a = api()) a->clear(); }
__attribute__((visibility("default"))) void hx_rpc_login()  { if (auto* a = api()) a->login(); }
__attribute__((visibility("default"))) void hx_rpc_logout() { if (auto* a = api()) a->logout(); }
__attribute__((visibility("default"))) void hx_rpc_set_state(const char* nick, int id, const char* server,
                                                             const char* ip, int port, int players, long long start) {
    if (auto* a = api()) a->setState(nick, id, server, ip, port, players, start);
}
__attribute__((visibility("default"))) int hx_rpc_status(char* out, int cap) {
    if (auto* a = api()) return a->status(out, cap);
    if (out && cap > 0) std::snprintf(out, static_cast<size_t>(cap), "%s", g_err);
    return 0;
}
__attribute__((visibility("default"))) int hx_rpc_flags() {
    if (auto* a = api()) return a->flags();
    return 0;
}

} // extern "C"

ON_MOD_UNLOAD() {
    if (auto* a = api()) a->stop();
}
