package com.discord.socialsdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/**
 * Replacement for the SDK's own NativeCalls (the original is stripped from the dex by the build).
 *
 * The original is written for an app that ships the SDK's manifest entries and the androidx
 * libraries. Inside the game none of that exists, so its login path (AuthenticationActivity,
 * Custom Tabs, a foreground service) throws on the main thread and kills the whole game.
 * The native SDK calls exactly these static methods (same names and signatures), so this version
 * keeps them but never throws: the login link is opened with a plain ACTION_VIEW intent and
 * everything else the game does not need is a safe no-op.
 */
public class NativeCalls {
    private static final String TAG = "HexedRPC";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public NativeCalls() {}

    // audio routing is not needed for rich presence
    public static void initializeAudioManager() {}
    public static void setActiveCall(boolean active) {}
    public static void setPreventCommsForBluetooth(boolean prevent) {}

    // Built-in browser login: it needs an Activity declared in the host manifest, which the game
    // does not have. Open the link in the browser instead and report failure if that is impossible.
    public static boolean authorize(final String url, final AuthenticationClientCallback callback) {
        if (open(url)) return true;
        try {
            if (callback != null) callback.onAuthorizationComplete(null, null, "no_browser_available");
        } catch (Throwable t) {
            Log.e(TAG, "authorize callback failed", t);
        }
        return false;
    }

    // no foreground service / notification channel (needs androidx + a manifest entry)
    public static void startForegroundService() {}
    public static void stopForegroundService() {}

    public static void openUrl(final String url) {
        open(url);
    }

    public static boolean isDiscordAppInstalled() {
        try {
            Activity a = DiscordSocialSdkInit.getEngineActivity();
            if (a == null) return false;
            String[] pkgs = { "com.discord", "com.discord.debug" };
            for (String p : pkgs) {
                try {
                    a.getPackageManager().getPackageInfo(p, 0);
                    return true;
                } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            Log.e(TAG, "isDiscordAppInstalled", t);
        }
        return false;
    }

    public static String getPackageName() {
        try {
            Activity a = DiscordSocialSdkInit.getEngineActivity();
            return a != null ? a.getPackageName() : "";
        } catch (Throwable t) {
            return "";
        }
    }

    // posts to the main thread; every failure is caught there so it can never take the game down
    private static boolean open(final String url) {
        if (url == null || url.isEmpty()) return false;
        final Activity a;
        try {
            a = DiscordSocialSdkInit.getEngineActivity();
        } catch (Throwable t) {
            Log.e(TAG, "no activity for openUrl", t);
            return false;
        }
        if (a == null) {
            Log.e(TAG, "openUrl: no engine activity");
            return false;
        }
        Log.i(TAG, "opening login link: " + url);
        MAIN.post(new Runnable() {
            @Override public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    a.startActivity(i);
                } catch (Throwable t) {
                    Log.e(TAG, "openUrl failed: " + t, t);
                }
            }
        });
        return true;
    }
}
