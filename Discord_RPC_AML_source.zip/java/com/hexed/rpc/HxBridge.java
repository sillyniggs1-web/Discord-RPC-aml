package com.hexed.rpc;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * Loaded by the stub through a DexClassLoader together with the Discord Social SDK classes.
 * Does the things the SDK needs from Java inside another app's process:
 *  - System.load()s the SDK by its absolute path first. (Loading it by name through the SDK's own
 *    static initializer can fail with "library not found" even though the file is there, and hides
 *    the real linker error. Loading by path reports the real reason.)
 *  - hands it the game's Activity (DiscordSocialSdkInit.setEngineActivity)
 *  - System.load()s the core library from THIS class loader, so the SDK and the core share one
 *    copy of libdiscord_partner_sdk.so and the same JNI class cache.
 */
public final class HxBridge {
    private HxBridge() {}

    private static String reflectError = "";

    /** Implemented in libhxrpc_core.so; returns the address of its HxApi function table. */
    public static native long apiTable();

    /** Returns null on success, otherwise a description of what failed. */
    public static String init(Context ctx, String sdkPath, String corePath) {
        try {
            try {
                System.load(sdkPath);
            } catch (Throwable t) {
                return "load SDK (" + sdkPath + "): " + describe(t);
            }
            Activity act = findActivity(ctx);
            if (act == null) {
                return "no running Activity found (AML context: " + (ctx == null ? "null" : ctx.getClass().getName())
                        + (reflectError.isEmpty() ? "" : "; " + reflectError) + ")";
            }
            // the static initializer of DiscordSocialSdkInit calls System.loadLibrary("discord_partner_sdk"):
            // the library is already loaded from the same path by this loader, so that is a no-op
            com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(act);
            try {
                System.load(corePath);
            } catch (Throwable t) {
                return "load core (" + corePath + "): " + describe(t);
            }
            return null;
        } catch (Throwable t) {
            return describe(t);
        }
    }

    private static String describe(Throwable t) {
        String m = t.getClass().getSimpleName() + ": " + t.getMessage();
        Throwable c = t.getCause();
        if (c != null && c != t) m += " <- " + c.getClass().getSimpleName() + ": " + c.getMessage();
        return m;
    }

    private static Activity findActivity(Context ctx) {
        Context c = ctx;
        for (int i = 0; c != null && i < 10; i++) {
            if (c instanceof Activity) return (Activity) c;
            if (!(c instanceof ContextWrapper)) break;
            Context base = ((ContextWrapper) c).getBaseContext();
            if (base == c) break;
            c = base;
        }
        try {
            return findActivityReflect();
        } catch (Throwable t) {
            reflectError = "ActivityThread lookup: " + describe(t);
            return null;
        }
    }

    private static Activity findActivityReflect() throws Exception {
        Class<?> at = Class.forName("android.app.ActivityThread");
        Object thread = at.getMethod("currentActivityThread").invoke(null);
        Field f = at.getDeclaredField("mActivities");
        f.setAccessible(true);
        Map<?, ?> map = (Map<?, ?>) f.get(thread);
        if (map == null) return null;
        for (Object rec : map.values()) {
            Field af = rec.getClass().getDeclaredField("activity");
            af.setAccessible(true);
            Object a = af.get(rec);
            if (a instanceof Activity) return (Activity) a;
        }
        return null;
    }
}
